# SLIDE: OUR AI AGENT FAMILY
## Introducing the 7 AI Agents

---

## SLIDE CONTENT

### Headline
**OUR AI AGENT FAMILY**

### Subheadline
**Central Hub: Client Success** — *7 Agents, 1 Goal*

---

### The 7 Agents

| Agent | What It Does |
|-------|--------------|
| **Profiler** | Understands your customers |
| **Selector** | Picks the right segments |
| **Matcher** | Attributes every response |
| **Reporter** | Generates intelligent insights |
| **Builder** | Creates custom models |
| **Optimizer** | Maximizes performance |
| **Monitor** | Tracks model health |

---

### Speaker
AMAN

---

## VISUAL RECOMMENDATIONS

**Layout:** Hub-and-spoke diagram
- "Client Success" in the center
- 7 agents as nodes radiating outward
- Each node has icon + agent name + short description

**Icon Ideas:**
| Agent | Icon |
|-------|------|
| Profiler | Magnifying glass / User profile |
| Selector | Crosshairs / Target |
| Matcher | Puzzle pieces |
| Reporter | Document / Chart |
| Builder | Hammer & gear |
| Optimizer | Sliders / Dial |
| Monitor | Heartbeat / Shield |

**Color:** Each agent could have a unique color or use consistent brand color with numbered badges

---

## SPEAKER NOTES

*"Meet the team. Seven AI agents, each specialized for a specific job.*

*They all have one goal: your success.*

*Let me show you how they work together."*

---

## FILE INFO

- **Slide Position:** After "What Makes It Intelligent?"
- **Primary Speaker:** Aman
- **Status:** Content Finalized ✅
