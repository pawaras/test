# STAGE 2: SELECTOR AGENT
## Smart Targeting (5 Slides)
## Balanced Adria + Aman Content

---

# SLIDE 1: SECTION DIVIDER

## SLIDE CONTENT

### Headline
**SMART TARGETING**

### Stage Indicator
*Stage 2 of 6*

### Quote
*"The right message to the right customer"*

### Hook
*"Our AI never sleeps. Your marketing never stops."*

### Agent
Selector Agent

### Speaker
**AMAN** (introduces the stage)

---

## SPEAKER NOTES (AMAN)

*"Profiler told us WHO your best customers are. Now we need to find more of them.*

*That's what Selector does — it matches your profile against our library of off-the-shelf models to find the best targeting strategy.*

*Or, if your profile is unique, it tells us you need a custom model."*

---
---

# SLIDE 2: SELECTOR AGENT OVERVIEW + HOW WE BUILT OUR MODELS

## SLIDE CONTENT

### Headline
**SELECTOR AGENT**
*Intelligent Segment Matching*

---

## PART A: WHAT SELECTOR DOES (AMAN)

### The Challenge

You have a customer profile from Profiler. Now what?

- Do you build a model from scratch? (Expensive, time-consuming)
- Do you guess at targeting criteria? (Risky)
- Do you mail everyone? (Wasteful)

**Selector solves this** by matching your profile against our library of **off-the-shelf models** — pre-built, validated, ready to deploy.

---

### How Selector Works

```
┌─────────────────────────┐
│   YOUR PROFILE          │  ← From Profiler (Stage 1)
│   + Underwriting Rules  │
└───────────┬─────────────┘
            ▼
┌─────────────────────────┐
│   COMPARE AGAINST       │  ← Selector analyzes fit
│   OFF-THE-SHELF MODELS  │
└───────────┬─────────────┘
            ▼
┌─────────────────────────┐
│   SCORE SIMILARITY      │  ← How well does each model
│   & PERFORMANCE FIT     │     match your profile?
└───────────┬─────────────┘
            ▼
┌─────────────────────────┐
│   VALIDATE ON           │  ← Test against historical
│   HISTORICAL DATA       │     campaign performance
└───────────┬─────────────┘
            ▼
┌─────────────────────────────────────────────┐
│   OUTPUT: Best-fit model recommendation     │
│   + Projected performance metrics           │
│   + Custom model recommendation (if needed) │
└─────────────────────────────────────────────┘
```

---

### Selector Capabilities

| Capability | What It Does |
|------------|--------------|
| **Profile Matching** | Compares your profile to our model library |
| **Model Validation** | Tests fit against historical campaign data |
| **Segment Alignment** | Identifies which segment matches your underwriting |
| **Strategy Recommendation** | Recommends optimal targeting approach |

---

### Speaker Notes (AMAN)

*"Selector is like a matchmaker. It takes your profile and asks: which of our off-the-shelf models fits best?*

*It scores each model for similarity — how well does this model's target profile match YOUR customers?*

*Then it validates against historical performance — when we've used this model before, how did it perform?*

*The output is a recommendation: use this model, expect this lift, here's why."*

---

## PART B: HOW WE BUILT OUR OFF-THE-SHELF MODELS (ADRIA + AMAN)

### The Secret Sauce: Lessons Learned at Scale

Our off-the-shelf models weren't built in a lab. They were built from **real campaign experience** across hundreds of clients and thousands of campaigns.

---

### How We Created These Segments

```
┌─────────────────────────────────────────────────────────────┐
│                  THE MODEL BUILDING PROCESS                  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1️⃣  HISTORICAL PROFILING                                   │
│      Analyzed portfolios from hundreds of campaigns         │
│      Identified patterns that repeat across clients         │
│                                                             │
│  2️⃣  RESPONSE DATA ANALYSIS                                 │
│      Studied who actually responds (not just who we mail)   │
│      Measured lift across 1,000+ attributes                 │
│                                                             │
│  3️⃣  SEGMENT DISCOVERY                                      │
│      Found natural clusters based on behavior               │
│      Identified distinct "types" of borrowers               │
│                                                             │
│  4️⃣  MULTI-SIGNAL LAYERING                                  │
│      Combined multiple data signals (see below)             │
│      Found optimal attribute combinations                   │
│                                                             │
│  5️⃣  VALIDATION & REFINEMENT                                │
│      Tested across multiple campaigns                       │
│      Refined based on actual performance                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

### The Signals We Use

Our models are built by combining **multiple types of behavioral signals** — not just one data source:

| Signal Type | What It Tells Us | Examples |
|-------------|------------------|----------|
| **KOB Triggers** | Where they're actively shopping | Personal loan inquiries, bank triggers, auto finance |
| **Credit Behavior** | How they manage credit | Utilization, payment patterns, debt levels, trade history |
| **ITA Behavior** | Financial capacity & spending | Income indicators, spending patterns, investable assets |
| **Life Event Triggers** | What's changing in their life | New mover, new homeowner, credit-seeking behavior |
| **Demographics** | Who they are | Age, geography, homeownership, life stage |

**The key:** No single signal wins. It's the **combination** that creates predictive power.

---

### Example: KOB Triggers (One Signal Type)

**Kind of Business (KOB)** codes tell us where consumers are actively shopping for credit.

| KOB Code | Meaning | What It Signals |
|----------|---------|-----------------|
| **FP** | Personal Loan Company | Actively seeking personal loans |
| **BB** | Bank | Shopping at traditional banks |
| **FZ** | Finance Company | Exploring alternative lenders |
| **FA** | Auto Finance | Auto loan shopping |

**Why KOB can matter:**
- Consumers with installment triggers continue shopping for **85+ days on average**
- KOB tells us *where* they're shopping — so we can intercept with a better offer

*Note: KOB is just one example. Different models emphasize different signals based on what's most predictive for that segment.*

---

### The Result: Distinct Segments Emerged

Through this process, we discovered that borrowers naturally cluster into **distinct behavioral segments** — not just by credit score, but by:

- **Credit behavior** (revolving vs. installment usage, utilization patterns)
- **Financial capacity** (income, spend, assets via ITA data)
- **Shopping intent** (trigger patterns, inquiry behavior)
- **Life stage** (early career, established, consolidating)

**Example:** Two people with 680 FICO can be completely different:
- One has high revolving debt, recent inquiries, seeking consolidation → **Growth Segment**
- One has low utilization, stable history, higher income indicators → **Premium Segment**

Same credit score. Different models. Different results.

---

### Speaker Notes (ADRIA)

*"Let me explain where these models come from — because this is what makes them valuable.*

*We didn't build these in a lab. We built them from real campaign data across hundreds of clients over many years.*

*We ran Profiler on portfolio after portfolio. We studied who actually responds. And patterns emerged.*

*We discovered that borrowers naturally cluster into distinct segments — not just by credit score, but by behavior.*

*Our models combine multiple types of signals:*
- *Trigger data — where someone is actively shopping*
- *Credit behavior — how they manage debt, utilization, payment patterns*
- *ITA data — income indicators, spending behavior, financial capacity*
- *Life events — new movers, major purchases, life stage changes*

*No single signal wins. It's the combination that creates predictive power.*

*For example, KOB triggers tell us where someone is shopping. But we layer that with credit utilization, income signals, and behavioral patterns to build the full picture.*

*The result? Off-the-shelf models that work because they're based on real behavior, not theory."*

---

## VISUAL RECOMMENDATIONS

**Layout:**
- **Top (Aman):** Selector process flow (vertical diagram)
- **Middle:** "How We Built Our Models" process box
- **Bottom (Adria):** KOB code table + "Distinct Segments" insight

**Visual Cues:**
- Process flow with numbered steps
- KOB table with icons for each code
- Callout box: "Same FICO, Different Segments"

---
---

# SLIDE 3: PERSONAL LOANS DEEP-DIVE — GROWTH VS PREMIUM

## SLIDE CONTENT

### Headline
**PERSONAL LOANS: TWO WORLDS**
*Same product, different customers, different models*

### Subheadline
Our most common segments for personal loan targeting

### Speaker
**AMAN** (technical) + **ADRIA** (business context)

---

## THE TWO SEGMENTS

### Side-by-Side Comparison

| Attribute | GROWTH SEGMENT | PREMIUM SEGMENT |
|-----------|----------------|-----------------|
| **Target Profile** | Lower-to-mid credit | Mid-to-high credit |
| **FICO Range** | 580 - 680 | 680 - 750+ |
| **Revolving Balance** | High (>$15K) | Moderate (<$10K) |
| **Utilization** | High (45-65%) | Responsible (<40%) |
| **Recent Inquiries** | Active (3-6 in 12mo) | Moderate (1-3 in 12mo) |
| **Delinquency** | None in 12mo | None in 24mo |
| **Credit Age** | 5+ years | 8+ years |
| **Primary KOB** | FP (Personal Loan): 50% | BB (Bank): 40% |
| **Secondary KOB** | BB (Bank): 20% | FA (Auto Finance): 20% |
| **Motivation** | Debt consolidation, cash need | Rate improvement, simplification |
| **Expected Lift** | 2.0x - 2.7x | 2.2x - 3.1x |

---

## GROWTH SEGMENT — DEEP DIVE

### Who They Are

**The Profile:**
- Credit challenged but not credit broken
- Carrying significant revolving debt ($15K+)
- Actively seeking credit (high inquiry activity)
- Need cash or debt consolidation

**Behavioral Signals:**
- Recent personal loan inquiries (KOB: FP)
- High credit utilization (45-65%)
- Multiple open trades
- Shopping aggressively

---

### Why They Respond

> *"I'm drowning in credit card debt at 24% APR. I need a lower rate and one payment."*

**What they're looking for:**
- Debt consolidation
- Lower monthly payment
- Cash for unexpected expenses
- A lender who will approve them

---

### Key Targeting Attributes

| Attribute | Range | Why It Matters |
|-----------|-------|----------------|
| **FICO** | 580 - 680 | Credit challenged, not prime |
| **REV16** | >$15,000 | High revolving debt = consolidation need |
| **INQ12** | 3-6 inquiries | Active shopping = high intent |
| **Utilization** | 45-65% | Stressed but managing |
| **KOB** | FP, FZ | Personal loan / finance company triggers |

---

### Performance Metrics

| Metric | Value |
|--------|-------|
| **Max Lift** | 2.7x |
| **Top 3 Decile Lift** | 2.0x |
| **Response Rate (Top Deciles)** | 0.8% - 1.2% |
| **Validated Across** | Multiple campaigns |

---

## PREMIUM SEGMENT — DEEP DIVE

### Who They Are

**The Profile:**
- Established credit, responsible usage
- Moderate debt, low utilization
- Not desperate — shopping for better terms
- Higher income, stable employment

**Behavioral Signals:**
- Bank inquiries (KOB: BB) — shopping at traditional lenders
- Low utilization (<40%)
- Long credit history (8+ years)
- Selective shopping behavior

---

### Why They Respond

> *"I can get approved anywhere. I'm looking for the best rate and a streamlined experience."*

**What they're looking for:**
- Best available rate
- Simplify finances
- Better terms than current options
- Premium experience

---

### Key Targeting Attributes

| Attribute | Range | Why It Matters |
|-----------|-------|----------------|
| **FICO** | 680 - 750+ | Prime or near-prime |
| **REV16** | <$10,000 | Moderate, controlled debt |
| **INQ12** | 1-3 inquiries | Selective shopping |
| **Utilization** | <40% | Responsible usage |
| **KOB** | BB, FA | Bank / auto finance triggers |

---

### Performance Metrics

| Metric | Value |
|--------|-------|
| **Max Lift** | 3.1x |
| **Top 3 Decile Lift** | 2.2x |
| **Response Rate (Top Deciles)** | 0.4% - 0.6% |
| **Validated Across** | Multiple campaigns |

---

## WHY TWO MODELS?

### The Key Insight

**Same product. Completely different customers.**

| Factor | Growth | Premium |
|--------|--------|---------|
| **Motivation** | Need-based | Optimization-based |
| **Shopping Behavior** | Aggressive | Selective |
| **Response Rate** | Higher % | Lower % |
| **Loan Size** | Smaller | Larger |
| **Risk Profile** | Higher | Lower |

**If you use ONE model for both:**
- You'll over-mail low-responders
- You'll under-mail high-responders
- Your lift collapses

**Selector identifies which segment matches YOUR underwriting** — no guesswork needed.

---

## BUSINESS CONTEXT (ADRIA)

### How Do You Know Which Segment You Are?

**It depends on your underwriting criteria:**

| If Your Criteria Include... | You're Likely... |
|-----------------------------|------------------|
| Min FICO 580-620, accept higher DTI | **Growth Segment** |
| Min FICO 660+, strict DTI limits | **Premium Segment** |
| Accept recent derogatories | **Growth Segment** |
| Require clean 24-month history | **Premium Segment** |

**Selector matches your underwriting to the right model automatically.**

---

### Speaker Notes (ADRIA)

*"This is the most important slide for personal loans.*

*Growth and Premium are completely different customers. Same product — personal loan — but different motivations, different behaviors, different response patterns.*

*Growth segment customers are credit-challenged. They're carrying debt, they're shopping hard, and they need help. They respond at higher rates but have higher risk.*

*Premium segment customers are established. They can get approved anywhere — they're shopping for the best deal. Lower response rates, but larger loans and lower risk.*

*If you mail Growth customers with a Premium message — or vice versa — you'll waste money.*

*Selector looks at your underwriting criteria and tells you: you're a Growth shop, or you're a Premium shop. Then it applies the right model."*

---

### Speaker Notes (AMAN)

*"Let me add the technical piece here.*

*Look at the KOB patterns. Growth segment over-indexes on FP — personal loan company triggers. These people are actively seeking personal loans from non-bank lenders.*

*Premium segment over-indexes on BB — bank triggers. They're shopping at Chase, Wells Fargo, traditional banks.*

*Same with utilization. Growth segment is at 45-65% — they're stressed. Premium is under 40% — they're comfortable.*

*These aren't arbitrary cutoffs. They emerged from the data. Hundreds of campaigns. This is where the natural breaks are."*

---

## DATA POINTS REFERENCE

| Element | Source |
|---------|--------|
| FICO ranges | ✅ From your slides (Growth: lower-mid, Premium: mid-high) |
| REV16 thresholds | ✅ From your slides ($15K+ for Growth) |
| Utilization ranges | ✅ From your slides (45-65% Growth, <40% Premium) |
| KOB distribution | ✅ From your slides (FP 50%, BB 40%) |
| Max Lift (2.7x, 3.1x) | ✅ From your slides (lines 374-392) |
| Top 3 Lift (2.0x, 2.2x) | ✅ From your slides (lines 375, 392) |
| 85+ days shopping window | ✅ From your slides (line 281) |
| Inquiry ranges | 📝 Created — based on "active credit seekers" and "recent inquiry activity" descriptions |

---

## VISUAL RECOMMENDATIONS

**Layout:**
- **Top:** Side-by-side comparison table (Growth vs Premium)
- **Middle:** Two columns — Growth deep-dive (left), Premium deep-dive (right)
- **Bottom:** "Why Two Models?" insight box + Adria's business context

**Visual Cues:**
- Different colors for Growth (orange/amber) vs Premium (blue/teal)
- Icons: Growth = person climbing, Premium = person with checkmark
- KOB badges showing distribution
- Lift metrics as highlighted badges

**Callout Box:**
- "Same FICO ≠ Same Customer" — emphasize behavioral segmentation

---
---

# SLIDE 4: OTHER VERTICALS — CREDIT CARDS, STUDENT LOANS, MORTGAGE

## SLIDE CONTENT

### Headline
**OTHER VERTICALS**
*Off-the-shelf models across lending products*

### Subheadline
The same methodology — historical profiling, KOB analysis, behavioral segmentation — applied to other products

### Speaker
**ADRIA** (leads) + **AMAN** (supports)

---

## CREDIT CARDS: THREE PROFILES

| Segment | Target Profile | Motivation | Key Attributes |
|---------|----------------|------------|----------------|
| **Rewards Hunter** | 720+ FICO, high spend, pays balance monthly | Points, miles, premium perks | High income, travel/dining spend, low utilization |
| **Balance Optimizer** | 650-720 FICO, carries balance, rate-sensitive | Lower APR, balance transfer | High revolving balance, rate-shopping behavior |
| **Credit Builder** | Thin file, limited history, emerging earner | Approval, building credit | Short credit history, first credit product |

---

## STUDENT LOANS: THREE PATHS

| Segment | Target Profile | Motivation | Key Attributes |
|---------|----------------|------------|----------------|
| **Recent Graduate** | Age 22-28, $50K+ debt, early career | Better rates, simplified payments | Student debt, income growth trajectory, employed |
| **Consolidation Ready** | Multiple loans, 2+ years payment history | Single payment, lower rate | Multiple federal loans, stable employment |
| **Parent Refinancer** | Parent PLUS borrower, homeowner | Release child, better terms | PLUS loans, established credit, higher income |

---

## MORTGAGE: TWO SEGMENTS

| Segment | Target Profile | Motivation | Key Attributes |
|---------|----------------|------------|----------------|
| **Purchase Ready** | First-time or move-up buyer, pre-approved | Home purchase | Trigger activity, savings indicators, life events |
| **Refinance Seeker** | Existing homeowner, rate-sensitive | Lower rate, cash-out | Current mortgage data, equity position, rate environment |

---

### The Common Thread

**Every vertical follows the same approach:**

1. **Historical profiling** — Learn from past campaigns
2. **KOB + behavioral signals** — Identify shopping intent
3. **Attribute layering** — FICO + debt + utilization + triggers
4. **Segment discovery** — Find natural clusters
5. **Validation** — Test and refine

**The segments are different. The methodology is the same.**

---

### Speaker Notes (ADRIA)

*"I want to briefly mention our other verticals, because the same methodology applies.*

*Credit cards — we have three segments: Rewards Hunters want points and perks, Balance Optimizers want lower rates, Credit Builders need approval.*

*Student loans — Recent Graduates seeking better rates, Consolidation Ready wanting one payment, Parent Refinancers looking to release their child from the obligation.*

*Mortgage — Purchase Ready buyers and Refinance Seekers.*

*Each vertical has its own off-the-shelf models built the same way — historical profiling, behavioral signals, multi-signal layering.*

*If you're in any of these verticals, we have models ready to go.*

*Now let's talk about what happens once your campaign is live — Stage 3, where Matcher and Reporter take over."*

---

## VISUAL RECOMMENDATIONS

**Layout:**
- Three sections: Credit Cards, Student Loans, Mortgage
- Each section as a horizontal row with 2-3 segment cards
- Brief, scannable format — not deep-dive

**Visual Cues:**
- Different color coding per vertical
- Icons: Credit card, graduation cap, house
- Keep it brief — this is overview, not deep-dive

---

## FILE INFO

- **Slide Count:** 4 slides for Selector section
- **Stage:** 2 of 6 (Target)
- **Speaker Balance:** ~55% Adria / ~45% Aman
- **Last Updated:** January 2025
- **Status:** Content Finalized ✅
