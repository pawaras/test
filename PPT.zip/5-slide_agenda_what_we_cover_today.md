# SLIDE: WHAT WE'LL COVER TODAY
## Agenda / Client Journey Overview

---

## SLIDE CONTENT

### Headline
**WHAT WE'LL COVER TODAY**

### Subheadline
*The Client Journey: From First Conversation to Continuous Growth*

---

### Main Content: The 6-Stage Journey

| Stage | What Happens | AI Agent |
|-------|--------------|----------|
| **1. Onboard** | Portfolio profiling & customer intelligence — *analyze across 1,000+ credit & demographic attributes* | Profiler Agent |
| **2. Target** | Segment selection & model matching — *20+ ready-to-deploy generic models across lending verticals* | Selector Agent |
| **3. Execute** | Campaign launch, response attribution & automated reporting — *powered by 500+ historical campaigns* | Matcher + Reporter Agents |
| **4. Build** | Custom ML model development — *20-30% lift improvement over generic models* | Builder Agent |
| **5. Optimize** | A/B testing & performance tuning — *5-15% improvement per cycle* | Optimizer Agent |
| **6. Refresh** | Model health monitoring & rebuild triggers — *automated drift detection & rebuild alerts* | Monitor Agent |

---

### Supporting Text

**The Continuous Loop:**
Each cycle builds on the previous — driving incremental improvement campaign after campaign.

---

### Tagline / Closing

*7 AI Agents. 1 Goal: Your Success.*

---

## DATA POINTS REFERENCE

| Stage | Data Point | Source | Notes |
|-------|------------|--------|-------|
| Onboard | "1,000+ credit & demographic attributes" | ✅ Original (line 201) | Direct from Profiler Agent capabilities |
| Target | "20+ ready-to-deploy generic models" | ✅ Original (line 321) | From Selector Agent matching process |
| Execute | "500+ historical campaigns" | ✅ Original (lines 576, 609, 1173) | InteliData Express repository |
| Build | "20-30% lift improvement" | 🔄 Modified | Corrected from original 20-50% per Aman's input |
| Optimize | "5-15% improvement per cycle" | ✅ Original (lines 938, 956) | From optimization cycle metrics |
| Refresh | "automated drift detection & rebuild alerts" | 📝 Created | Summarized from Monitor Agent capabilities (lines 1038-1040); not a direct stat from slides |

---

## VISUAL DESIGN RECOMMENDATIONS

### Layout Option 1: Circular Journey Diagram
- Create a **circular/loop diagram** with 6 nodes arranged in a clockwise flow
- Each node represents a stage with icon + stage name + AI agent name
- Arrows connect each stage showing the continuous flow
- Center of circle contains: *"7 AI Agents. 1 Goal: Your Success."*
- Use a **return arrow** from Stage 6 back to Stage 1 to emphasize the continuous loop

### Layout Option 2: Horizontal Roadmap
- **Linear roadmap** with 6 milestones from left to right
- Each milestone as a pin/marker on the road
- Road curves back at the end to show the cycle continues
- Data hooks appear as callout boxes below each milestone

### Layout Option 3: Numbered Cards/Tiles
- **6 cards/tiles** arranged in 2 rows of 3
- Each card contains: Stage number, name, description, data hook, agent icon
- Cards connected with subtle arrows or numbered sequence
- Tagline at bottom spans full width

---

### Color & Icon Suggestions

**Stage Icons (suggestions):**
| Stage | Icon Idea |
|-------|-----------|
| 1. Onboard | Magnifying glass / User profile |
| 2. Target | Crosshairs / Bullseye |
| 3. Execute | Rocket / Play button |
| 4. Build | Hammer & wrench / Building blocks |
| 5. Optimize | Sliders / Dial gauge |
| 6. Refresh | Circular arrows / Sync icon |

**Color Coding:**
- Consider using a **gradient progression** (e.g., light blue → dark blue) across the 6 stages to show advancement
- Or use **consistent brand colors** with numbered badges for differentiation
- Data hook stats should be in an **accent color** (e.g., teal, orange) to stand out

**AI Agent Badges:**
- Small badge or icon next to each stage showing the agent name
- Could use a **robot/AI icon** with the agent name as a label
- Keep consistent styling across all 7 agents for visual cohesion

---

### Animation Recommendations (for final presentation)

**Build Animation Sequence:**
1. Headline + Subheadline appear first
2. Stages reveal one-by-one (1 → 2 → 3 → 4 → 5 → 6) with ~0.5s delay each
3. Data hooks fade in as each stage appears (italicized stats)
4. Connecting arrows/flow lines animate after all stages visible
5. "Continuous Loop" text + return arrow animates
6. Tagline fades in last as the punchline

**Presenter Notes:**
- Pause briefly on each stage as it appears
- Use this slide as a "preview" — don't explain each stage in detail here
- Reference: "We'll dive deep into each of these, starting with Onboard"

---

### Typography Recommendations

- **Headline:** Bold, large (32-40pt)
- **Subheadline:** Italic, medium (20-24pt)
- **Stage Names:** Bold, medium (18-22pt)
- **Descriptions:** Regular, smaller (14-16pt)
- **Data Hooks:** Italic, accent color (14-16pt)
- **Tagline:** Bold italic, medium (18-22pt), centered at bottom

---

## TOOLS RECOMMENDED FOR CREATION

| Tool | Best For |
|------|----------|
| **Gamma AI** | Quick generation of journey diagram layouts; good for initial structure |
| **Canva** | Custom icons, polished cards/tiles layout, brand color consistency |
| **PowerPoint/Google Slides** | SmartArt for circular diagrams, precise animation control |
| **Midjourney** | Generate custom AI agent icons or abstract journey visuals (if desired) |
| **Figma** | If you want pixel-perfect custom design with exportable assets |

---

## SPEAKER NOTES (for presentation)

*"Before we dive in, here's the journey we'll take you through today. This is the same journey every client takes with us — from that first conversation to continuous, compounding improvement.*

*We've built 7 specialized AI agents — each one designed to handle a specific stage of this journey. You'll meet all of them today.*

*Notice this is a loop, not a line. After Stage 6, we circle back. Each cycle builds on what we learned before. That's how we drive 30-50% cumulative annual gains for our clients.*

*Let's start at the beginning — Onboard."*

---

## FILE INFO

- **Slide Position:** Early in deck (after Title, Presenters, and DDM Overview slides)
- **Estimated Speaking Time:** 1-2 minutes
- **Last Updated:** January 2025
- **Status:** Content Finalized ✅
