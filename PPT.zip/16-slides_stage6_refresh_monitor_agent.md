# STAGE 6: REFRESH — MODEL HEALTH MONITORING
## Monitor Agent (2 Slides)
## Balanced Adria + Aman Content

---

# SLIDE 1: SECTION DIVIDER

## SLIDE CONTENT

### Headline
**MODEL REFRESH & MONITORING**

### Stage Indicator
*Stage 6 of 6*

### Quote
*"Models age. Markets change."*

### Hook
*"Our AI never sleeps. Your marketing never stops."*

### Agent
Monitor Agent

### Speaker
**AMAN**

---

## SPEAKER NOTES (AMAN)

*"Your model is built, optimized, and performing. But here's the reality: nothing lasts forever.*

*Markets change. Customer behavior shifts. What worked last year might not work next year.*

*Monitor Agent watches your model health and tells you when it's time to refresh."*

---
---

# SLIDE 2: MONITOR AGENT — KEEPING MODELS HEALTHY

## SLIDE CONTENT

### Headline
**MONITOR AGENT**
*Automated Model Health Tracking*

---

### What Monitor Does

| Capability | What It Tracks |
|------------|----------------|
| **Performance Tracking** | Is lift holding steady or declining? |
| **Drift Detection** | Are response patterns changing? |
| **Health Scoring** | Overall model health at a glance |
| **Rebuild Alerts** | Notifies when refresh is needed |

---

### Health Indicators

| Indicator | Status | Meaning |
|-----------|--------|---------|
| ✅ **Lift Stable** | Green | Within 10% of validation |
| ⚠️ **Response Drift** | Yellow | 15-25% below expected |
| 🔴 **Model Age** | Red | >18 months, rebuild recommended |

---

### When to Refresh

| Trigger | Threshold |
|---------|-----------|
| **Performance Drop** | Lift down >20% from baseline |
| **Model Age** | 12-18 months |
| **Business Changes** | New products, markets, or underwriting |

---

### The Continuous Loop

```
    STAGE 1          STAGE 2          STAGE 3
    Profile    →     Target     →     Execute
       ↑                                  ↓
    STAGE 6          STAGE 5          STAGE 4
    Refresh    ←    Optimize    ←     Build
```

**The journey never ends.** After refresh, we cycle back — each iteration smarter than the last.

---

### Speaker Notes (AMAN)

*"Monitor tracks three things: Is lift holding? Are response patterns drifting? How old is the model?*

*When any of these hit a threshold — performance drops 20%, model hits 18 months, or your business changes significantly — Monitor alerts you.*

*Then we refresh. Rebuild the model with new data. And the cycle continues.*

*That's the complete journey. Six stages. Seven AI agents. Continuous improvement."*

---

### Speaker Notes (ADRIA)

*"From a business perspective, this is your insurance policy.*

*You don't want to find out your model degraded after a bad campaign. Monitor catches it early.*

*And when it's time to refresh, we already have the data and the process. No starting from scratch.*

*That's the DDM advantage: a system that gets smarter over time, not one you have to rebuild from the ground up every year."*

---

## VISUAL RECOMMENDATIONS

**Layout:**
- **Top:** What Monitor does (4 capabilities)
- **Middle:** Health indicators (traffic light style: green/yellow/red)
- **Bottom:** Continuous loop diagram showing all 6 stages

**Visual Cues:**
- Traffic light icons for health status
- Circular journey diagram connecting all stages
- Simple, clean — this is a short wrap-up slide

---

## FILE INFO

- **Slide Count:** 2 slides for Refresh section
- **Stage:** 6 of 6 (Refresh)
- **Agent:** Monitor
- **Speaker Balance:** Aman leads, Adria supports
- **Last Updated:** January 2025
- **Status:** Content Finalized ✅
