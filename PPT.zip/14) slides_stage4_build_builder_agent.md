# STAGE 4: BUILD — CUSTOM MODEL DEVELOPMENT
## Builder Agent (4 Slides)
## Balanced Adria + Aman Content

---

# SLIDE 1: SECTION DIVIDER

## SLIDE CONTENT

### Headline
**CUSTOM MODEL BUILDING**

### Stage Indicator
*Stage 4 of 6*

### Quote
*"Your customers, your model, your advantage"*

### Hook
*"Our AI never sleeps. Your marketing never stops."*

### Agent
Builder Agent

### Speaker
**AMAN** (introduces the stage)

---

## SPEAKER NOTES (AMAN)

*"You've been running campaigns with our off-the-shelf models. They're working — you're seeing lift, you're getting responses.*

*But now the question is: can we do better?*

*The answer is yes. A custom model — built on YOUR data, trained on YOUR responders — will outperform off-the-shelf every time.*

*This is Stage 4: Build."*

---
---

# SLIDE 2: WHEN TO LEVEL UP

## SLIDE CONTENT

### Headline
**WHEN TO LEVEL UP**
*From off-the-shelf to custom*

---

## PART A: THE BUSINESS CASE (ADRIA)

### Why Custom Beats Off-the-Shelf

| Off-the-Shelf Models | Custom Models |
|----------------------|---------------|
| Built from industry patterns | Built from YOUR customers |
| Good starting point | Optimized for your specific goals |
| General targeting | Precision targeting |
| Solid lift | **20-30% better lift** |

**The math is simple:** Custom models consistently outperform because they learn YOUR customers and YOUR definition of success.

---

### The ROI Conversation

> *"We're happy with current results. Why invest in a custom model?"*

**Answer:**

| Current State | With Custom Model | Impact |
|---------------|-------------------|--------|
| Response Rate: X | Response Rate: X + 20-30% | More responses, same mail volume |
| Mailing 500K pieces | Could mail 400K for same results | Lower cost, same outcome |
| Good ROI | Better ROI | Compounding improvement |

**Custom models don't just improve one campaign — they improve every campaign going forward.**

---

### Speaker Notes (ADRIA)

*"Let me make the business case for custom models.*

*Off-the-shelf models are built from industry patterns. They work — that's why we start there. But they're general purpose.*

*A custom model is built from YOUR data. Your responders. Your definition of success.*

*The result? 20-30% improvement in lift. That's not a one-time bump — that's every campaign, compounding over time.*

*If you're mailing 500,000 pieces, a 20% lift improvement means either more responses at the same cost, or the same responses at lower cost. Either way, your ROI improves.*

*So when should you make the move? Aman, what are the triggers?"*

---

## PART B: THE THREE TRIGGERS (AMAN)

### Ready for a Custom Model?

Three signals that tell us it's time:

---

### Trigger 1: Sufficient Responders

**What it means:** You've collected enough response data to build a statistically valid model.

| Threshold | Status |
|-----------|--------|
| < 3,000 responders | Not yet — keep running campaigns |
| 3,000 - 5,000 responders | Getting close — start planning |
| **5,000+ responders** | ✅ Ready for custom model |

*More responders = more signal = better model.*

---

### Trigger 2: Unique Patterns

**What it means:** Your customer base shows distinct characteristics that differ from the generic segments.

**Signals:**
- Profiler shows attributes that don't match typical Growth or Premium patterns
- Your best customers have unusual combinations of behaviors
- Off-the-shelf model lift is good but plateauing

*If you're different, you need a model that knows that.*

---

### Trigger 3: Scale Ambition

**What it means:** You're ready to significantly increase campaign volume and need better efficiency to make it work.

**Signals:**
- Planning to 2x or 3x mail volume
- Need better ROI to justify larger investment
- Want to expand into new segments

*Bigger campaigns demand better targeting.*

---

### Speaker Notes (AMAN)

*"Three triggers tell us you're ready.*

*First: sufficient responders. We need enough data to build a valid model. The threshold is around 5,000 responders — fewer than that and the model won't be reliable.*

*Second: unique patterns. If Profiler shows that your customers don't fit the typical Growth or Premium profile — if they have unusual attribute combinations — then the off-the-shelf model isn't capturing what makes YOUR customers different.*

*Third: scale ambition. If you're planning to double or triple your volume, you need better efficiency to make the economics work. Custom models deliver that efficiency.*

*When we see these signals, we recommend making the move."*

---

## VISUAL RECOMMENDATIONS

**Layout:**
- **Top (Adria):** Business case comparison table + ROI conversation
- **Bottom (Aman):** Three trigger cards with icons and thresholds

**Visual Cues:**
- Checkmark for "Ready" status
- Progress indicator for responder thresholds
- Icons: #1 = people/data, #2 = fingerprint/unique, #3 = rocket/growth

---
---

# SLIDE 3: BUILDER AGENT — HOW WE BUILD CUSTOM MODELS

## SLIDE CONTENT

### Headline
**BUILDER AGENT**
*End-to-End ML Pipeline*

---

## PART A: THE VALUE (ADRIA)

### What Builder Delivers

| What You Get | Why It Matters |
|--------------|----------------|
| **Custom-built model** | Trained on YOUR responders |
| **Validated performance** | Tested before deployment |
| **Interpretable outputs** | Understand why it works |
| **Ongoing support** | Monitor, refresh, optimize |

**You don't need a data science team.** Builder handles the complexity — you get the results.

---

### Speaker Notes (ADRIA)

*"Builder is our ML pipeline agent. It handles the entire model development process — from raw data to deployed model.*

*What does that mean for you? You don't need a data science team. You don't need to understand the algorithms. You give us the data, we build the model, and you get results.*

*The output is interpretable — you'll understand why the model works and which attributes are driving performance. That's important for stakeholder buy-in and regulatory compliance.*

*Aman, walk us through how Builder actually works."*

---

## PART B: THE ML PIPELINE (AMAN)

### How Builder Works

```
┌─────────────────────────────────────────────────────────────┐
│                    BUILDER ML PIPELINE                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1️⃣  DATA PREPARATION                                       │
│      • Clean and format your response data                  │
│      • Tag attributes, handle missing values                │
│      • Create training and testing datasets                 │
│                                                             │
│  2️⃣  FEATURE ENGINEERING                                    │
│      • Start with 1,000+ potential attributes               │
│      • Test each for predictive power                       │
│      • Select top 50-70 most predictive features            │
│                                                             │
│  3️⃣  MODEL TRAINING                                         │
│      • Test multiple modeling approaches                    │
│      • Each approach competes on your data                  │
│      • Best performer becomes the champion                  │
│                                                             │
│  4️⃣  VALIDATION                                             │
│      • Test on held-out data (never seen during training)   │
│      • Verify lift, stability, and performance              │
│      • Ensure model generalizes to new data                 │
│                                                             │
│  5️⃣  DEPLOYMENT                                             │
│      • Score your prospect universe                         │
│      • Create targeting deciles                             │
│      • Ready for campaign execution                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

### Feature Selection: From 1,000+ to 50-70

| Stage | What Happens |
|-------|--------------|
| **Start** | 1,000+ credit & demographic attributes |
| **Filter** | Remove low-predictive attributes |
| **Rank** | Score remaining by importance |
| **Select** | Keep top 50-70 features |

**Why 50-70?** Enough signal to capture patterns, not so many that we overfit.

---

### The Model Tournament (Simplified)

We don't bet on one approach. We test **multiple modeling techniques** and let them compete:

| What We Test | Why |
|--------------|-----|
| Multiple algorithms | Different approaches find different patterns |
| Various configurations | Optimize for your specific data |
| Ensemble methods | Combine strengths of multiple models |

**The winner?** Whichever approach performs best on YOUR data becomes the champion model.

*We're not picking favorites — we're letting the data decide.*

---

### Speaker Notes (AMAN)

*"Builder runs a full ML pipeline. Let me walk you through it.*

*Step 1: Data preparation. We take your response data, clean it, format it, and split it into training and testing sets.*

*Step 2: Feature engineering. We start with over 1,000 attributes and narrow down to the 50-70 that are most predictive for YOUR customers. Not industry patterns — your patterns.*

*Step 3: Model training. This is where it gets interesting. We don't just pick one algorithm and hope for the best. We test multiple approaches — different techniques, different configurations — and let them compete on your data.*

*The best performer wins. We call it the model tournament. The data decides the champion, not us.*

*Step 4: Validation. We test the champion on held-out data — data the model has never seen. This ensures it generalizes and doesn't just memorize the training set.*

*Step 5: Deployment. We score your prospect universe, create deciles, and you're ready to execute."*

---

## VISUAL RECOMMENDATIONS

**Layout:**
- **Top (Adria):** Value proposition table
- **Middle (Aman):** Pipeline flow diagram (5 steps)
- **Bottom:** Feature selection funnel + tournament concept

**Visual Cues:**
- Funnel graphic: 1,000+ → 50-70 features
- Trophy icon for "champion model"
- Pipeline as vertical flow with numbered steps

---
---

# SLIDE 4: CUSTOM MODEL SUCCESS — RESULTS

## SLIDE CONTENT

### Headline
**CUSTOM MODEL RESULTS**
*Real performance from a real client*

### Subheadline
Personal Loan — Growth Segment Custom Model

### Speaker
**AMAN** (technical results) + **ADRIA** (business impact)

---

## THE JOURNEY

### How We Got Here

| Stage | What Happened |
|-------|---------------|
| **Started** | Client used off-the-shelf Growth Segment model |
| **Ran Campaigns** | Multiple campaigns over several months |
| **Collected Data** | 10,000+ responders accumulated |
| **Built Custom** | Builder created custom model from their data |
| **Validated** | Tested on fresh, out-of-time data |
| **Deployed** | Custom model now powers all campaigns |

---

## THE RESULTS

### Custom vs. Off-the-Shelf Performance

| Metric | Off-the-Shelf | Custom Model | Improvement |
|--------|---------------|--------------|-------------|
| **Max Lift (Decile 1)** | Good | Better | **+40-50%** |
| **Top 3 Lift** | Solid | Stronger | **+35-45%** |
| **Overall ROI** | Positive | Higher | **Significant** |

---

### Why Custom Won

| Factor | Off-the-Shelf | Custom |
|--------|---------------|--------|
| Training data | Industry patterns | THIS client's responders |
| Target definition | Generic "response" | Client's specific success metric |
| Attribute weights | Average across clients | Optimized for this portfolio |

**The model learned what makes THIS client's customers different.**

---

### Model Output: What We Delivered

**Top Predictive Attributes (Custom Model):**

| Rank | Attribute | Direction | Importance |
|------|-----------|-----------|------------|
| 1 | Recent Inquiry Activity | Positive | High |
| 2 | Revolving Balance | Positive | High |
| 3 | Account Age | Negative | Medium |
| 4 | Utilization Ratio | Positive | Medium |
| 5 | Open Trade Count | Positive | Medium |

*Every model is interpretable. We can explain why it works.*

---

### Sample Gains Table

| Decile | Universe | Target % | Lift | Cumulative |
|--------|----------|----------|------|------------|
| **1** | 10% | High | ⭐⭐⭐ | Best performers |
| **2** | 10% | Strong | ⭐⭐⭐ | Strong |
| **3** | 10% | Above avg | ⭐⭐ | Good |
| 4-5 | 20% | Average | ⭐ | Moderate |
| 6-10 | 50% | Below avg | — | Reduce/cut |

**Clear separation:** Top deciles significantly outperform bottom deciles.

---

## THE BUSINESS IMPACT (ADRIA)

### What This Means

> **"With the custom model, we can now:**
>
> - **Mail smarter:** Focus on deciles 1-3, reduce 6-10
> - **Get more responses:** 40-50% lift improvement
> - **Spend less:** Same results with fewer pieces
> - **Compound gains:** Every future campaign benefits"

---

### Validation Metrics

Builder validates every model against these thresholds:

| Metric | What It Measures | Target |
|--------|------------------|--------|
| **Max Lift** | Top decile performance | ≥ 2.0x |
| **Top 3 Lift** | Top 30% performance | ≥ 1.4x |
| **Linearity** | Consistent rank ordering | ≥ 0.7 |

**This model passed all validation checks.**

---

### Speaker Notes (AMAN)

*"Let me show you real results from a custom model we built.*

*This client started with our off-the-shelf Growth Segment model. Good results — solid lift, positive ROI.*

*Over several months, they accumulated over 10,000 responders. That triggered the custom model build.*

*Builder trained a model on their specific data. The result? 40-50% improvement in max lift. 35-45% improvement in top 3 lift.*

*Look at the attribute output. Recent inquiry activity and revolving balance are the top drivers — consistent with Growth Segment, but weighted specifically for this client's patterns.*

*The gains table shows clear separation. Deciles 1-3 significantly outperform. That's a well-built model.*

*And it's interpretable. We can explain every attribute, every weight, every prediction."*

---

### Speaker Notes (ADRIA)

*"From a business standpoint, here's what this delivers.*

*The client can now focus their budget on deciles 1-3 — where the lift is highest. They can reduce or cut deciles 6-10 — saving mail costs without losing responses.*

*The 40-50% lift improvement isn't a one-time thing. Every campaign going forward uses this model. The gains compound.*

*And this is just Stage 4. The model is built. Now we optimize — Stage 5 — and monitor for drift — Stage 6.*

*The journey doesn't end. It gets better."*

---

### What Happens Next?

**Stage 4 Complete:** Custom model built and validated.

**Stage 5: Optimize** — Continuous improvement through A/B testing and performance tuning.

*"A good model can always get better."*

---

## DATA POINTS REFERENCE

| Element | Source |
|---------|--------|
| 20-30% lift improvement (custom vs. generic) | ✅ From earlier slides (corrected figure) |
| 5,000+ responder threshold | ✅ From your slides (line 692) |
| 1,000+ attributes → 50-70 features | ✅ From your slides (line 763) |
| Max Lift ≥ 2.0, Top 3 ≥ 1.4, Linearity ≥ 0.7 | ✅ From your slides (lines 840-844) |
| 40-50% improvement example | 📝 Created — based on your slides showing +44.8% and +49.4% (lines 850-852) |
| 10,000+ responders | 📝 Created — illustrative based on "11,000+" in your deck (line 887) |
| Attribute rankings | 📝 Created — based on typical Growth Segment patterns |

---

## VISUAL RECOMMENDATIONS

**Layout:**
- **Top:** Journey timeline (6 steps)
- **Middle:** Results comparison table + attribute output
- **Bottom:** Gains table (simplified) + business impact quote

**Visual Cues:**
- Before/after comparison (off-the-shelf vs. custom)
- Star ratings for gains table deciles
- Checkmarks for validation metrics passed
- Arrow to Stage 5

---

## FILE INFO

- **Slide Count:** 4 slides for Build section
- **Stage:** 4 of 6 (Build)
- **Agent:** Builder
- **Speaker Balance:** ~50% Adria / ~50% Aman
- **Last Updated:** January 2025
- **Status:** Content Finalized ✅
