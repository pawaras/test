#!/bin/bash


sudo sed -i "$ a http://EVAPzen.fpl.com:10262" /etc/yum.conf