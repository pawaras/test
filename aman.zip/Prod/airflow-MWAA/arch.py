import os

from airflow import DAG
from airflow.operators.python_operator import PythonOperator,BranchPythonOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from datetime import datetime, timedelta
import time
from dateutil.relativedelta import relativedelta
from airflow.utils.dates import days_ago
from airflow.models.param import Param
from airflowUtils.conf import *

import json
import boto3
from datetime import datetime
import logging
from botocore.client import Config
import sys
import airflowUtils.emr_utils as emr
import re
from botocore.exceptions import ClientError


logger = logging.getLogger("airflow.task")



default_args = {
    'owner': 'airflow',
    'start_date': datetime(2022,12,1),
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'provide_context': True
}

# Initialize the DAG 0 0 1 * *
dag = DAG('load_research_archive', concurrency=3, schedule_interval=None, default_args=default_args)
config = Config(connect_timeout=30, read_timeout=30, proxies={'https': 'http://EVAPzen.fpl.com:10262'})
Subject='Archival Process - Airflow- Task Error'



running_date = str((datetime.now()).strftime('%Y%m%d'))
audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])

region = emr.get_region()
emr.client(region_name=region, config=config)

def read_config():
    _configuration = emr.get_config(AIRFLOW_S3_BUCKET, 'dags/alr_configuration/load_research.json')
    Contact = _configuration['Contact']
    AppCode = _configuration['AppCode']
    cluster_name = _configuration['cluster_name']
    log_bucket = _configuration['log_bucket_name']
    Topic = _configuration['aws_sns_Topic']
    input_bucket_name = _configuration['input_bucket_name']
    sm_name = _configuration['sm_name']
    error_log_group = _configuration['error_log_group']

    running_date = str((datetime.now()).strftime('%Y%m%d'))
    audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])
    emr_conf = _configuration['emr_conf']

    return {
        'Contact': Contact,
        'AppCode': AppCode,
        'cluster_name': cluster_name,
        'log_bucket': log_bucket,
        'Topic': Topic,
        'sm_name': sm_name,
        'error_log_group': error_log_group,
        'running_date': running_date,
        'audit_running': audit_running,
        'emr_conf': emr_conf,
        'input_bucket_name':input_bucket_name,
        'code_bucket_name': _configuration['code_bucket_name']
    }


# Creates an EMR cluster
def create_emr(**kwargs):
    dag_config = read_config()
    cluster_name = dag_config['cluster_name']
    emr_conf = dag_config['emr_conf']
    Contact = dag_config['Contact']
    AppCode = dag_config['AppCode']
    print(region)
    print(cluster_name)
    cluster_id = emr.check_emr_cluster(cluster_name)
    if cluster_id != None:
        logger.info('Cluster already exists')
    else:
        cluster_id = emr.create_emr_cluster_ALR(emr_conf, region_name=region, cluster_name=cluster_name, AppCode=AppCode,
                                            Contact=Contact)
        logger.info(cluster_id)
        if cluster_id != None:
            emr.wait_for_cluster_creation(cluster_id)

    return cluster_id



# Terminates the EMR cluster
def terminate_emr(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    logger.info(cluster_id)
    #emr.terminate_cluster(cluster_id)


def send_sns(Topic, Message, Subject= 'Archive DAG Error'):
    logger.info('SNS')
    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=Subject
        )
        logger.info("response SNS: {}".format(response))
    except Exception as e:
        logger.info('Error SNS: {}'.format(e))
    return response


def error_task(context):
    instance = context['task_instance']
    logger.info('context-taks-error')
    logger.info(context)
    dag_config = read_config()
    Topic = dag_config['Topic']
    Message = "Error - LR fetch data dag: Please review log in Airflow for more information."
    resp = send_sns(Topic, Message, Subject)
    return True



def transform_emr_livy_arch(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    cluster_dns = emr.get_cluster_dns(cluster_id)
    logger.info(cluster_dns)
    code_file = 'local:/home/hadoop/long_arch.py'

    dag_config = read_config()
    sm_name = dag_config['sm_name']

    code_args = kwargs['code_args']

    logger.info(code_args)

    data = {"file": code_file, "args": code_args,
            "conf": {"livy.spark.deployMode": "client", "spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "spark.executorEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.executorEnv.PYTHONHOME": "/usr/bin/python3"}}

    logger.info(data)
    try:
        headers, id = emr.submit_spark_script(cluster_dns, data)
    except Exception as e:
         logger.info('Error: {}'.format(e))
    return True


process_archive = PythonOperator(
    task_id='process_archive',
    python_callable=transform_emr_livy_arch,
    op_kwargs={
        'code_args': [],
        'process_name': 'ALR',
    },
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)


create_cluster = PythonOperator(
    task_id='create_cluster',
    python_callable=create_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)



terminate_cluster = PythonOperator(
    task_id='terminate_cluster',
    python_callable=terminate_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)


# setting the dependencies

create_cluster >> process_archive  >> terminate_cluster
