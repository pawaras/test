import os

from airflow import DAG
from airflow.operators.python_operator import PythonOperator,BranchPythonOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from datetime import datetime, timedelta
import time
from dateutil.relativedelta import relativedelta
from airflow.utils.dates import days_ago
from airflow.models.param import Param
from airflowUtils.conf import *

import json
import boto3
from datetime import datetime
import logging
from botocore.client import Config
import sys
import airflowUtils.emr_utils as emr
import re
from botocore.exceptions import ClientError

logger = logging.getLogger("airflow.task")
# logger.setLevel(logging.INFO)


default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'provide_context': True
}

# Initialize the DAG
dag = DAG('load_research_validations', concurrency=3, schedule_interval=None, default_args=default_args)


config = Config(connect_timeout=30, read_timeout=30, proxies={'https': 'http://EVAPzen.fpl.com:10262'})
Subject = 'ALR Validations - Airflow - Task Error'


#region ='us-east-1'

running_date = str((datetime.now()).strftime('%Y%m%d'))
audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])
region = emr.get_region()
emr.client(region_name=region, config=config)

def read_config():
    _configuration = emr.get_config(AIRFLOW_S3_BUCKET, 'dags/alr_configuration/load_research.json')
    Contact = _configuration['Contact']
    AppCode = _configuration['AppCode']
    cluster_name = _configuration['cluster_name']
    log_bucket = _configuration['log_bucket_name']
    Topic = _configuration['aws_sns_Topic']
    input_bucket_name = _configuration['input_bucket_name']
    sm_name = _configuration['sm_name']
    error_log_group = _configuration['error_log_group']

    running_date = str((datetime.now()).strftime('%Y%m%d'))
    audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])
    emr_conf = _configuration['emr_conf']

    return {
        'Contact': Contact,
        'AppCode': AppCode,
        'cluster_name': cluster_name,
        'log_bucket': log_bucket,
        'Topic': Topic,
        'sm_name': sm_name,
        'error_log_group': error_log_group,
        'running_date': running_date,
        'audit_running': audit_running,
        'emr_conf': emr_conf,
        'input_bucket_name':input_bucket_name,
        'code_bucket_name': _configuration['code_bucket_name']
    }


# Creates an EMR cluster
def create_emr(**kwargs):
    dag_config = read_config()
    cluster_name = dag_config['cluster_name']
    emr_conf = dag_config['emr_conf']
    Contact = dag_config['Contact']
    AppCode = dag_config['AppCode']
    print(region)
    print(cluster_name)
    cluster_id = emr.check_emr_cluster(cluster_name)
    if cluster_id != None:
        logger.info('Cluster already exists')
    else:
        cluster_id = emr.create_emr_cluster(emr_conf, region_name=region, cluster_name=cluster_name, AppCode=AppCode,
                                            Contact=Contact)
        logger.info(cluster_id)
        if cluster_id != None:
            emr.wait_for_cluster_creation(cluster_id)

    return cluster_id



# Terminates the EMR cluster
def terminate_emr(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    logger.info(cluster_id)
    terminate_cluster = kwargs['dag_run'].conf['action']
    if terminate_cluster == "Terminate":
        emr.terminate_cluster(cluster_id)


def send_sns(Topic, Message, Subject= 'Error'):
    logger.info('SNS')
    response = None
    dag_config = read_config()
    error_log_group = dag_config['error_log_group']
    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=str(Subject)
        )
        logger.info("response SNS: {}".format(response))
        emr.put_error_cloudwatch(error_log_group, str(Message))
    except Exception as e:
        logger.info('Error SNS: {}'.format(e))
    return response


def error_task(context):
    instance = context['task_instance']
    logger.info('context-taks-error')
    logger.info(context)
    dag_config = read_config()
    Topic = dag_config['Topic']
    Message = "Error - LR fetch data dag: Please review log in Airflow for more information."
    resp = send_sns(Topic, Message, Subject)
    return True




def transform_emr_livy_validation(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    cluster_dns = emr.get_cluster_dns(cluster_id)
    logger.info(cluster_dns)

    greg_date = kwargs['dag_run'].conf['greg_date']
    audit_id= kwargs['dag_run'].conf['audit_id']
    process = kwargs['dag_run'].conf['process']

    code_file = 'local:/home/hadoop/data/validations.py'

    dag_config = read_config()
    Topic = dag_config['Topic']
    error_log_group = dag_config['error_log_group']
    sm_name = dag_config['sm_name']

    code_args = kwargs['code_args']
    code_args.append("-g {}".format(greg_date))
    code_args.append("-a {}".format(audit_id))
    code_args.append("-p {}".format(process))
    code_args.append("-s {}".format(sm_name.strip()))
    code_args.append("-e {}".format(Topic))
    code_args.append("-c {}".format(error_log_group))
    logger.info("Value of {} for key=greg_date".format(greg_date))
    logger.info("Value of {} for key=audit_id".format(audit_id))

    logger.info(code_args)

    data = {"file": code_file, "args": code_args,
            "conf": {"livy.spark.deployMode": "client", "spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "spark.executorEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.executorEnv.PYTHONHOME": "/usr/bin/python3"}}

    logger.info(data)
    try:
        headers, id = emr.submit_spark_script(cluster_dns, data)
    except Exception as e:
        logger.info('Error: {}'.format(e))
    return True


def transform_emr_livy_readiness(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    cluster_dns = emr.get_cluster_dns(cluster_id)
    logger.info(cluster_dns)
    code_file = 'local:/home/hadoop/data/readiness.py'

    dag_config = read_config()
    sm_name = dag_config['sm_name']

    code_args = kwargs['code_args']
    code_args.append("-s {}".format(sm_name.strip()))


    logger.info(code_args)

    data = {"file": code_file, "args": code_args,
            "conf": {"livy.spark.deployMode": "client", "spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "spark.executorEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.executorEnv.PYTHONHOME": "/usr/bin/python3"}}

    logger.info(data)
    try:
        headers, id = emr.submit_spark_script(cluster_dns, data)
    except Exception as e:
         logger.info('Error: {}'.format(e))
    return True



def trigger_dag_lse(context, dag_run_obj):
    ti = context['task_instance']
    greg_date = context['dag_run'].conf['greg_date']
    process_type = context['dag_run'].conf['process_type']
    print('greg_date: {}'.format(greg_date))
    job_params = ti.xcom_pull(key='job_params', task_ids='router')
    return {"greg_date":greg_date }



should_trigger = PythonOperator(
    task_id="should_trigger",
    python_callable=trigger_dag_lse,
    provide_context=True,
)

lse_process = TriggerDagRunOperator(
    task_id='lse_process',
    trigger_dag_id="load_research_lse",
    conf={"greg_date": "{{ dag_run.conf['greg_date'] }}", "process_type":"Daily"},
    dag=dag
)


process_validations = PythonOperator(
    task_id='process_validations',
    python_callable=transform_emr_livy_validation,
    op_kwargs={
        'code_args': [],
        'process_name': 'ALR',
    },
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)


process_readiness = PythonOperator(
    task_id='process_readiness',
    python_callable=transform_emr_livy_readiness,
    op_kwargs={
        'code_args': [],
        'process_name': 'ALR',
    },
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)



create_cluster = PythonOperator(
    task_id='create_cluster',
    python_callable=create_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)



terminate_cluster = PythonOperator(
    task_id='terminate_cluster',
    python_callable=terminate_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)




# setting the dependencies

create_cluster >> process_validations >> process_readiness >> lse_process >>terminate_cluster
