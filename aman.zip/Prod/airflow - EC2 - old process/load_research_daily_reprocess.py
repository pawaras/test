import os

from airflow import DAG
from airflow.operators.python_operator import PythonOperator,BranchPythonOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators import TriggerDagRunOperator
from datetime import datetime, timedelta
import time
from dateutil.relativedelta import relativedelta
from airflow.utils.dates import days_ago

import json
import boto3
from datetime import datetime
import logging
from botocore.client import Config
import sys
import airflowUtils.emr_utils as emr
import psycopg2
import re
from botocore.exceptions import ClientError

logger = logging.getLogger("airflow.task")
# logger.setLevel(logging.INFO)


default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
    'depends_on_past': False,
    # 'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'provide_context': True
}

# Initialize the DAG
dag = DAG('load_research_daily_reprocess', concurrency=3, schedule_interval=None, default_args=default_args)


config = Config(connect_timeout=30, read_timeout=30, proxies={'https': 'http://EVAPzen.fpl.com:10262'})
Subject='ALR - Airflow - Task Error'


region = emr.get_region()
emr.client(region_name=region, config=config)

_configuration = emr.get_config('load_research.json')
Contact = _configuration['Contact']
AppCode = _configuration['AppCode']
cluster_name = _configuration['cluster_name']
log_bucket = _configuration['log_bucket_name']
Topic = _configuration['aws_sns_Topic']
input_bucket_name = _configuration['input_bucket_name']
sm_name = _configuration['sm_name']
error_log_group = _configuration['error_log_group']

running_date = str((datetime.now()).strftime('%Y%m%d'))
audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])


emr_conf = _configuration['emr_conf']

# Creates an EMR cluster
def create_emr(**kwargs):
    print(region)
    print(cluster_name)
    cluster_id = emr.check_emr_cluster(cluster_name)
    if cluster_id != None:
        logger.info('Cluster already exists')
    else:
        cluster_id = emr.create_emr_cluster(emr_conf, region_name=region, cluster_name=cluster_name, AppCode=AppCode,
                                            Contact=Contact)
        logger.info(cluster_id)
        if cluster_id != None:
            emr.wait_for_cluster_creation(cluster_id)

    return cluster_id



# Terminates the EMR cluster
def terminate_emr(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    logger.info(cluster_id)
    emr.terminate_cluster(cluster_id)


def send_sns(Topic, Message, Subject= 'Error'):
    logger.info('SNS')
    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=str(Subject)
        )
        logger.info("response SNS: {}".format(response))
        emr.put_error_cloudwatch(error_log_group, str(Message))
    except Exception as e:
        logger.info('Error SNS: {}'.format(e))
    return response


def error_task(context):
    instance = context['task_instance']
    logger.info('context-taks-error')
    logger.info(context)
    Message = "Error - LR reprocess dag. Please review log in Airflow for more information"
    #Message = context
    resp = send_sns(Topic, Message, Subject)
    return True


def stop_task(**kwargs):
    logger.info('dag Run_id : {}'.format(kwargs['dag_run'].run_id))
    return True


def get_secret_manager(connection_key, target=None):
    try:
        sm_client = boto3.client('secretsmanager', region_name=region)
        get_secret_value_response = sm_client.get_secret_value(
            SecretId=connection_key)
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e

    secretstring = get_secret_value_response['SecretString'].replace('\n', '')

    secret = json.loads(secretstring)
    connection = secret[target]
    return connection



def get_connection():
    connection = get_secret_manager(sm_name,"greenplum_dag")
    try:
        host = connection['url']
        logger.info("host : {} ".format(host))
        c_conn = psycopg2.connect(host=host, user=connection['username'], password=connection['password'],
                                  database=connection['db_name'], port= connection['port'])
    except Exception as e:
        print(e)
        print("ERROR: Unexpected error: Could not connect to the instance.")
        raise e
    return c_conn



def get_date_list(greg_date):
    _records = None
    date_list = []
    sql = "select greg_date from utl.day where (greg_date between '{}'::date and current_date -8) and cycl_day_num != 0 order by greg_date".format(greg_date)

    logger.info("sql : {} ".format(sql))
    try:
        c_conn = get_connection()
        cursor = c_conn.cursor()
        cursor.execute(sql)
        _records = cursor.fetchall()
        for row in _records:
            date_list.append(row[0])
        c_conn.commit()
    except psycopg2.DatabaseError as e:
        if c_conn:
            c_conn.rollback()
        print("Error=>" + str(e))
    except Exception as e:
        print("Error=>" + str(e))
    finally:
        if c_conn:
            cursor.close()
            c_conn.close()
    return date_list






def validations(greg_date,  cluster_dns, audit_id ):

    code_file = 'local:/home/hadoop/data/validations.py'
    code_args =[]

    code_args.append("-g {}".format(greg_date))
    code_args.append("-a {}".format(audit_id))
    code_args.append("-p daily")
    code_args.append("-s {}".format(sm_name.strip()))

    logger.info(code_args)

    data = {"file": code_file, "args": code_args,
            "conf": {"livy.spark.deployMode": "client", "spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "spark.executorEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.executorEnv.PYTHONHOME": "/usr/bin/python3"}}

    logger.info(data)
    try:
        headers, id = emr.submit_spark_script(cluster_dns, data)
    except Exception as e:
        logger.info('Error: {}'.format(e))
    return True




def readiness(code_args, cluster_dns):
    code_file = 'local:/home/hadoop/data/readiness.py'
    code_args =[]
    code_args.append("-s {}".format(sm_name.strip()))
    data = {"file": code_file, "args": code_args,
            "conf": {"livy.spark.deployMode": "client", "spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "spark.executorEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.executorEnv.PYTHONHOME": "/usr/bin/python3"}}

    logger.info(data)
    try:
        headers, id = emr.submit_spark_script(cluster_dns, data)
    except Exception as e:
        logger.info('Error: {}'.format(e))
    return True


def transform_emr_livy_lr(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    cluster_dns = emr.get_cluster_dns(cluster_id)
    logger.info(cluster_dns)
    logger.info('Process ID: {}'.format(kwargs['process_name']))


    p_start_date = kwargs['dag_run'].conf['p_start_date'] if kwargs['dag_run'].conf else running_date
    logger.info("Value of {} for key=p_start_date".format(p_start_date))

    greg_date = (datetime.strptime(p_start_date, '%Y%m%d')).strftime('%Y-%m-%d')

    p_start_date_li = get_date_list(greg_date)
    print(p_start_date_li)

    code_args = kwargs['code_args']

    for greg_date in p_start_date_li:
        logger.info("Value of p_start_date_li = {} ".format(greg_date))
        running_incremental = str((greg_date).strftime('%Y%m%d'))
        logger.info("Value of running_incremental  = {} ".format(running_incremental ))
        audit_id = "{}{}{}".format(kwargs['process_name'],running_incremental, kwargs['dag_run'].run_id)
        logger.info("Value of audit_id  = {} ".format(audit_id ))
        validations(greg_date,  cluster_dns, audit_id)
        #readiness(code_args, cluster_dns)
    return True




process_load_research = PythonOperator(
    task_id='process_load_research',
    python_callable=transform_emr_livy_lr,
    op_kwargs={
        'code_args': [],
        'process_name': 'D',
    },
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)




create_cluster = PythonOperator(
    task_id='create_cluster',
    python_callable=create_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)



terminate_cluster = PythonOperator(
    task_id='terminate_cluster',
    python_callable=terminate_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)



# setting the dependencies


create_cluster >> process_load_research >> terminate_cluster

