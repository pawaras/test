import os

from airflow import DAG
from airflow.operators.python_operator import PythonOperator,BranchPythonOperator
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta
import time
from dateutil.relativedelta import relativedelta
from airflow.utils.dates import days_ago

import json
import boto3
from datetime import datetime
import logging
from botocore.client import Config
import sys
import airflowUtils.emr_utils as emr

logger = logging.getLogger("airflow.task")
# logger.setLevel(logging.INFO)


default_args = {
    'owner': 'airflow',
    'start_date': datetime(2022,12,1),
    'depends_on_past': False,
    # 'email': ['soni.mirani@fpl.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'provide_context': True
}

# Initialize the DAG
dag = DAG('Load_Research_Archive', concurrency=3, schedule_interval='0 0 1 * *', default_args=default_args)
#dag = DAG('Load_Research_Archive', concurrency=3, schedule_interval=None, default_args=default_args)

#config = Config(connect_timeout=30, read_timeout=30, proxies={'https': 'http://webproxyeva.fpl.com:8080'})
config = Config(connect_timeout=30, read_timeout=30, proxies={'https': 'http://EVAPzen.fpl.com:10262'})
Subject='Archival Process - Airflow- Task Error'


region = emr.get_region()
emr.client(region_name=region, config=config)

_configuration = emr.get_config('load_research.json')
Contact = _configuration['Contact']
AppCode = _configuration['AppCode']
cluster_name =  _configuration['cluster_name']
log_bucket =  _configuration['log_bucket_name']
Topic=  _configuration['aws_sns_Topic']


running_date = str((datetime.now()).strftime('%Y%m%d'))
audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])


# emr_conf = _configuration['emr_conf']

def send_sns(Topic, Message, Subject= 'Archive DAG Error'):
    logger.info('SNS')
    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=Subject
        )
        logger.info("response SNS: {}".format(response))
    except Exception as e:
        logger.info('Error SNS: {}'.format(e))
    return response


def error_task(context):
    instance = context['task_instance']
    logger.info('context-taks-error')
    logger.info(context)
    Message = f"The Long Term Archive DAG failed to ccmplete, Please check Airflow logs."
    resp = send_sns(Topic, Message, Subject)
    return True


cmd = "python3 /opt/airflow/dags/long_arch.py "

run_arch = BashOperator(
    task_id='run_archive',
    bash_command=cmd,
    on_failure_callback= error_task,
    dag=dag
)

# setting the dependencies
run_arch
