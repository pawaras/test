import os

from airflow import DAG
from airflow.operators.python_operator import PythonOperator,BranchPythonOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators import TriggerDagRunOperator
from datetime import datetime, timedelta
import time
from dateutil.relativedelta import relativedelta
from airflow.utils.dates import days_ago

import json
import boto3
from datetime import datetime
import logging
from botocore.client import Config
import sys
import airflowUtils.emr_utils as emr
import psycopg2
import re
from botocore.exceptions import ClientError

logger = logging.getLogger("airflow.task")



default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'provide_context': True
}

# Initialize the DAG
dag = DAG('load_research_data_fetch', concurrency=3, schedule_interval='30 18 * * *', default_args=default_args)


config = Config(connect_timeout=30, read_timeout=30, proxies={'https': 'http://EVAPzen.fpl.com:10262'})
Subject = 'ALR Fetch Data- Airflow - Task Error'


region = emr.get_region()
emr.client(region_name=region, config=config)

_configuration = emr.get_config('load_research.json')
Contact = _configuration['Contact']
AppCode = _configuration['AppCode']
cluster_name = _configuration['cluster_name']
log_bucket = _configuration['log_bucket_name']
Topic = _configuration['aws_sns_Topic']
input_bucket_name = _configuration['input_bucket_name']
sm_name = _configuration['sm_name']
error_log_group = _configuration['error_log_group']
dag_name = 'load_research_data_fetch'

running_date = str((datetime.now()).strftime('%Y%m%d'))
audit_running = str((datetime.now()).strftime('%Y%m%d-%H:%M:%S.%f')[:-3])


emr_conf = _configuration['emr_conf']

# Creates an EMR cluster
def create_emr(**kwargs):
    print(region)
    print(cluster_name)
    cluster_id = emr.check_emr_cluster(cluster_name)
    if cluster_id != None:
        logger.info('Cluster already exists')
    else:
        cluster_id = emr.create_emr_cluster(emr_conf, region_name=region, cluster_name=cluster_name, AppCode=AppCode,
                                            Contact=Contact)
        logger.info(cluster_id)
        if cluster_id != None:
            emr.wait_for_cluster_creation(cluster_id)

    return cluster_id



# Terminates the EMR cluster
def terminate_emr(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    logger.info(cluster_id)
    emr.terminate_cluster(cluster_id)


def send_sns(Topic, Message, Subject= 'Error'):
    logger.info('SNS')
    response = None
    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=str(Subject)
        )
        logger.info("response SNS: {}".format(response))
        emr.put_error_cloudwatch(error_log_group, str(Message))
    except Exception as e:
        logger.info('Error SNS: {}'.format(e))
    return response


def error_task(context):
    instance = context['task_instance']
    logger.info('context-taks-error')
    logger.info(context)
    #Message = context
    Message = "Error - LR fetch data dag: Please review log in Airflow for more information."
    resp = send_sns(Topic, Message, Subject)
    return True


def stop_task(**kwargs):
    logger.info('dag Run_id : {}'.format(kwargs['dag_run'].run_id))
    return True


def get_secret_manager(connection_key, target=None):
    try:
        sm_client = boto3.client('secretsmanager', region_name=region)
        get_secret_value_response = sm_client.get_secret_value(
            SecretId=connection_key)
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            raise e

    secretstring = get_secret_value_response['SecretString'].replace('\n', '')

    secret = json.loads(secretstring)
    connection = secret[target]
    return connection



def get_connection():
    connection = get_secret_manager(sm_name,"alr_validation")
    try:
        host = connection['url']
        logger.info("host : {} ".format(host))
        c_conn = psycopg2.connect(host=host, user=connection['username'], password=connection['password'],
                                  database=connection['db_name'], port= connection['port'])
    except Exception as e:
        print(e)
        print("ERROR: Unexpected error: Could not connect to the instance.")
        raise e
    return c_conn



def check_bill_date(**kwargs):
    cycl_day_num = 0
    p_start_date = kwargs['dag_run'].conf['p_start_date'] if kwargs['dag_run'].conf else running_date
    logger.info("Value of {} for key=p_start_date".format(p_start_date))
    c_date = str(datetime.strptime(p_start_date, '%Y%m%d').date())
    logger.info("Value of c_date = {} ".format(c_date))
    sql = "select cycl_day_num  from clr.day where greg_date = '{}'::date - interval '8 days' and cycl_day_num is not null".format(c_date)
    logger.info("sql : {} ".format(sql))

    try:
        c_conn = get_connection()
        cursor = c_conn.cursor()
        cursor.execute(sql)
        _records = cursor.fetchall()
        for row in _records:
            cycl_day_num = row[0]
        c_conn.commit()
    except psycopg2.DatabaseError as e:
        if c_conn:
            c_conn.rollback()
        print("Error=>" + str(e))
    except Exception as e:
        print("Error=>" + str(e))
    finally:
        if c_conn:
            cursor.close()
            c_conn.close()
    logger.info("cycl_day_num : {} ".format(cycl_day_num))
    if cycl_day_num == 0 :
        return 'stop_dag'
    return 'create_cluster'



def transform_emr_livy_lr(**kwargs):
    ti = kwargs['ti']
    cluster_id = ti.xcom_pull(task_ids='create_cluster')
    cluster_dns = emr.get_cluster_dns(cluster_id)
    logger.info(cluster_dns)
    logger.info('Process ID: {}'.format(kwargs['process_name']))

    code_file = 'local:/home/hadoop/loadresearch.py'
    audit_id = "{}-{}".format(kwargs['process_name'], kwargs['dag_run'].run_id)
    process_id = 'loadresearch'

    code_args = kwargs['code_args']
    code_args.append("-j {}".format(audit_id))
    code_args.append("-t {}".format(Topic))
    code_args.append("-g {}".format(error_log_group))
    code_args.append("-d {}".format(dag_name))
    p_start_date = kwargs['dag_run'].conf['p_start_date'] if kwargs['dag_run'].conf else running_date
    logger.info("Value of {} for key=p_start_date".format(p_start_date))
    if p_start_date != running_date:
        code_args.append("-s {}".format(p_start_date))
    logger.info(code_args)

    data = {"file": code_file, "args": code_args,
            "conf": {"livy.spark.deployMode": "client", "spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "spark.executorEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.appMasterEnv.PYSPARK_PYTHON": "/usr/bin/python3",
                     "livy.spark.yarn.executorEnv.PYTHONHOME": "/usr/bin/python3"}}

    logger.info(data)
    try:
        headers, id = emr.submit_spark_script(cluster_dns, data)
    except Exception as e:
        logger.info('Error: {}'.format(e))
    return audit_id


def get_audit_results(**kwargs):
    ti = kwargs['ti']
    audit_id = ti.xcom_pull(task_ids='process_load_research')
    logger.info(audit_id)
    process_id = 'loadresearch'
    error_audit, error_msg = emr.get_audit(audit_id, process_id, 4)
    logger.info('Error:{}'.format(error_msg))
    if error_audit == True:
        error_msg = 'error: The daily fetch was not completed today. Please review log in Airflow for more information.'
        resp = send_sns(Topic, error_msg, Subject)
        return 'terminate_cluster'
    return 'validation_process'



def trigger_dag_validation(context, dag_run_obj):
    ti = context['task_instance']
    audit_id = ti.xcom_pull(task_ids='process_load_research')
    p_start_date = context['dag_run'].conf['p_start_date'] if context['dag_run'].conf else running_date
    greg_date = str(((datetime.strptime(p_start_date, '%Y%m%d')) - timedelta(days=8)).strftime('%Y-%m-%d'))
    _folder = 'lse_daily'
    #_file_name = '{}_{}'.format(_folder, greg_date)
    input_file = 's3://{}/{}'.format(input_bucket_name, _folder)
    job_params = ti.xcom_pull(key='job_params', task_ids='router')
    dag_run_obj.payload = {"greg_date":greg_date, "audit_id":audit_id, "input_file":input_file, "action": "NoTerminate"}
    return dag_run_obj


validation_process = TriggerDagRunOperator(
    task_id='validation_process',
    trigger_dag_id="load_research_validations",
    python_callable=trigger_dag_validation,
    params={'condition_param': True, 'task_payload': '{}'},
    dag=dag,
    wait_for_completion=True,
    provide_context=True,
)


process_load_research = PythonOperator(
    task_id='process_load_research',
    python_callable=transform_emr_livy_lr,
    op_kwargs={
        'code_args': ["-u {}/loadresearch/process_loadresearch.json".format(_configuration['code_bucket_name']), "-z 200"],
        'process_name': 'ALR',
    },
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)


check_cycl_day = BranchPythonOperator(
    task_id='check_cycl_day',
    python_callable=check_bill_date,
    dag=dag,
)



check_audit = BranchPythonOperator(
    task_id='check_audit',
    python_callable=get_audit_results,
    dag=dag,
)



create_cluster = PythonOperator(
    task_id='create_cluster',
    python_callable=create_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)



terminate_cluster = PythonOperator(
    task_id='terminate_cluster',
    python_callable=terminate_emr,
    on_failure_callback= error_task,
    provide_context=True,
    dag=dag)


stop_dag = PythonOperator(
    task_id='stop_dag',
    python_callable=stop_task,
    provide_context=True,
    dag=dag)


# setting the dependencies

check_cycl_day >> [create_cluster, stop_dag ]
create_cluster >> process_load_research >> check_audit >>   [validation_process, terminate_cluster]
validation_process
