import psycopg2
import pandas as pd
import io
from datetime import datetime
import pytz
import boto3
import logging
import json
from botocore.exceptions import ClientError
from pyspark import SparkConf
from pyspark.sql import SparkSession
import argparse
import sys

def get_parameter_options(parser, args):
    parsed, extra = parser.parse_known_args(args[1:])
    if extra:
        print('unrecognized arguments:', extra)
    return vars(parsed)

def parse_arguments(args):
    parser = argparse.ArgumentParser(prog=args[0])
    parser.add_argument('-s', '--sm_name')
    options = get_parameter_options(parser, args)
    return options


def get_connection_jdbc(sm_client, connection_key, target=None):
    try:
        get_secret_value_response = sm_client.get_secret_value(
            SecretId=connection_key)
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e

    secretstring = get_secret_value_response['SecretString'].replace('\n', '')

    secret = json.loads(secretstring)
    connection = secret[target]

    return connection

region_name = "us-east-1"

sm_client = boto3.client('secretsmanager', region_name=region_name)

print('connection_key')
options = parse_arguments(sys.argv)
sm_name = options.get('sm_name')
connection_key = sm_name.strip()
print(connection_key)
connection = get_connection_jdbc(sm_client, connection_key, 'alr_validation')


# Set the username/password
host = connection['url']
username = connection['username']
password = connection['password']  # pragma: allowlist secret
db_name = connection['db_name']
schema = connection['schema']
port = connection['port']
topic = connection['topic']

#topic = 'arn:aws:sns:us-east-1:977465404123:2fnv-lo174-sns-topic' # Test topic

def get_connection():
    conn = None
    try:
        print("Opening Connection")
        conn = psycopg2.connect(host = host, user=username, password=password, database=db_name, port=port) # pragma: allowlist secret
    except Exception as e:
        print (e)
        print("ERROR: Unexpected error: Could not connect to RDS instance.")
        raise e
    return conn

def read_postgres_to_df(sql):
    conn = None
    df=pd.DataFrame()
    try:
        conn = get_connection()
        df = pd.read_sql(sql, conn)
    except Exception as e:
        print(e)
    finally:
        if(conn is not None ):
            print("Closing Connection")
            conn.close()
    return df

def write_df_to_postgres(df, table_name, columns_names):
    conn = get_connection()
    cursor = conn.cursor()

    f = io.StringIO()
    df.to_csv(f, index=False, header=False, sep="|")
    f.seek(0)

    sql= "COPY {} FROM STDIN WITH DELIMITER AS '|' NULL AS ''".format(table_name)
    cursor.copy_expert(sql, f)
    cursor.close()
    conn.commit()
    conn.close()

def send_sns(region,Topic, Message, Subject='Error'):

    logger = logging.getLogger('readiness')

    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=Subject
        )

        logger.info("response SNS: {}".format(response))

    except Exception as e:
        logger.info('Error SNS: {}'.format(e))

    return response

def check_monthly_stratum(schema, rltv_mo, studyid):
    print("Checking monthlystratum")

    sql2 = f"select * from {schema}.monthlystratum where deleted_flg is distinct from True"
    monthlystratum = read_postgres_to_df(sql2)
    print("monthlystratum loaded")

    if len(monthlystratum[(monthlystratum.rltv_mo == rltv_mo) & (monthlystratum.studyid == studyid)]) > 0:
        print("monthlystratum ready")
        return True
    else:
        print("monthlystratum not ready")
        return False

def check_system_peak(schema, rltv_mo):
    print("Checking systempeak")

    sql3 = f"select * from {schema}.systempeak where deleted_flg is distinct from True"
    systempeak = read_postgres_to_df(sql3)
    print("systempeak loaded")

    if rltv_mo in systempeak.rltv_mo.unique():
        print("systempeak ready")
        return True
    else:
        print("systempeak not ready")
        return False

def check_readiness(rltv_mo, studyid):
    print(str(rltv_mo) + " " + studyid)

    ready_df = not_ready_ms_df = not_ready_sp_df = pd.DataFrame(columns=['rltv_mo','studyid'])

    ms_ready = check_monthly_stratum(schema, rltv_mo, studyid)
    if ms_ready == False:
        not_ready_ms_df = pd.DataFrame(data={'rltv_mo': [rltv_mo], 'studyid': [studyid]})

    sp_ready = check_system_peak(schema, rltv_mo)
    if sp_ready == False:
        not_ready_sp_df = pd.DataFrame(data={'rltv_mo': [rltv_mo], 'studyid': [studyid]})

    if (ms_ready == True) & (sp_ready == True):
        ready_df = pd.DataFrame(data={'rltv_mo': [rltv_mo],'studyid': [studyid]})

    return ready_df, not_ready_ms_df, not_ready_sp_df

def get_spark_env():
    conf = SparkConf().set("spark.jars", "/home/hadoop/jars/postgresql-42.2.12.jar,/home/hadoop/jars/mssql-jdbc-8.2.2.jre8.jar,/home/hadoop/jars/cobol-parser-0.2.5.jar,/home/hadoop/jars/spark-cobol-0.2.5.jar,/home/hadoop/jars/scodec-core_2.11-1.10.3.jar,/home/hadoop/jars/scodec-bits_2.11-1.1.4.jar")\
        .set('spark.executor.memory', '37G')\
        .set('spark.driver.memory', '37G') \
        .set("spark.executor.memoryOverhead", "5g") \
        .set('spark.kryoserializer.buffer.max', '128m')

    spark = SparkSession.builder. \
        appName("loadresearch"). \
        config(conf=conf). \
        getOrCreate()
    return spark



def main():
    '''
    Check for new studyid/rltv_mo combos in active_premise.
    if study/mo in active_premise but not in etl_monthly_readiness:
        call check_readiness for study/mo
    Get list of studies that are ready/not ready
    Write to etl_monthly_readiness
    Send to SNS
    '''


    # Spark environment
    spark = get_spark_env()


    active_premises = read_postgres_to_df(f"select distinct ap.studyid, rltv_mo from {schema}.active_premise ap inner join (select distinct studyid from {schema}.study where deleted_flg is distinct from true and case when enddate = '9999-12-31' then enddate else enddate + 60 end > current_date) s on s.studyid = ap.studyid")
    print("active_premises loaded")

    monthly_readiness = read_postgres_to_df(f"select * from {schema}.etl_monthly_readiness")
    print("monthly_readiness loaded")


    # Get list of studies/rltv_mo combinations that are in active_premise but have not yet been processed
    i1 = active_premises[['studyid', 'rltv_mo']].set_index(['studyid', 'rltv_mo']).index
    i2 = monthly_readiness[['studyid', 'rltv_mo']].set_index(['studyid', 'rltv_mo']).index
    new_study_mos = active_premises[~i1.isin(i2)][['studyid', 'rltv_mo']].drop_duplicates().sort_values(
        ['studyid', 'rltv_mo'])

    if len(new_study_mos) == 0:
        print("No new study/rltv_mo combos found in active_premise")

    # Create dataframes to keep track of:
        # Which studies/rltv_mos are ready
        # Which studies/rltv_mos aren't in monthly stratum
        # Which rltv_mos aren't  in systempeak
    ready_df = not_ready_ms_df = not_ready_sp_df = pd.DataFrame(columns=['rltv_mo','studyid'])
    for row in new_study_mos.values:
        ready_df_new, not_ready_ms_new, not_ready_sp_new = check_readiness(row[1], row[0])
        ready_df = ready_df.append(ready_df_new)
        not_ready_ms_df = not_ready_ms_df.append(not_ready_ms_new)
        not_ready_sp_df = not_ready_sp_df.append(not_ready_sp_new)

    ready_df = ready_df.sort_values(['rltv_mo','studyid'])
    not_ready_ms_df = not_ready_ms_df.sort_values(['rltv_mo','studyid'])
    not_ready_sp_df = not_ready_sp_df.sort_values(['rltv_mo','studyid'])

    # Use dfs to make SNS message:
    subject = "Monthly Readiness Notification"

    message = "Processing is now ready for the following studies/cycle months:\n"
    message = message + ready_df.to_string(index = False)

    if (len(not_ready_ms_df) > 0) | (len(not_ready_sp_df) > 0):
        message = message + "\n\nHowever..."
    if len(not_ready_ms_df) > 0:
        message = message + "\nmonthly stratum is not ready for the following studies/cycle months:\n"
        message = message + not_ready_ms_df.to_string(index = False) + "\n"
    if len(not_ready_sp_df) > 0:
        message = message + "\nsystempeak is not ready for the following cycle months:"
        for mo in not_ready_sp_df.rltv_mo.unique():
            message = message + "\n\t" + str(mo)

    # Only send SNS/write to etl when new studies/rltv_mos are ready
    if len(ready_df) > 0:
        print(f"Writing record to etl_monthly_readiness")
        etl_monthly_readiness = ready_df.copy()
        etl_monthly_readiness['readiness_dt'] = datetime.now(pytz.timezone("US/Eastern"))
        write_df_to_postgres(etl_monthly_readiness,
                             table_name = f'{schema}.etl_monthly_readiness',
                             columns_names=list(etl_monthly_readiness))
        print(etl_monthly_readiness)

        print("Sending SNS:")
        print(subject)
        print("_____________________________________________________________________")
        print(message)
        send_sns(region_name, topic, message, Subject=subject)


if __name__=="__main__":
    main()