import argparse
import json
import psycopg2
import boto3
from botocore.exceptions import ClientError
import sys
import io
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import pytz
from pyspark import SparkConf
from pyspark.sql import SparkSession
from dateutil import  relativedelta
# import os
# from io import StringIO

def get_parameter_options(parser, args):
    parsed, extra = parser.parse_known_args(args[1:])
    if extra:
        print('unrecognized arguments:', extra)
    return vars(parsed)

def parse_arguments(args):
    parser = argparse.ArgumentParser(prog=args[0])
    parser.add_argument('-g', '--greg_date') # like 202107 for monthly or 2021-01-21 for daily
    parser.add_argument('-a', '--audit_id')
    parser.add_argument('-p', '--process')  # daily, backdate, or reprocess
    parser.add_argument('-s', '--sm_name')
    parser.add_argument('-e', '--sns_topic', required=False, help='sns Topic')
    parser.add_argument('-c', '--cw_log_group', required=False, help='CloudWatch')
    options = get_parameter_options(parser, args)
    return options


def put_error_cloudwatch(region, log_group, error_msg):
    client = boto3.client('logs', region_name=region)

    logGroupName = log_group
    logStreamName = f"{log_group}-" + datetime.utcnow().__str__().replace(":", "")

    log_stream = client.create_log_stream(
        logGroupName=logGroupName,
        logStreamName=logStreamName
    )

    log_event = client.put_log_events(
        logGroupName=logGroupName,
        logStreamName=logStreamName,
        logEvents=[
            {
                'timestamp': int(time.time() * 1000),
                'message': str(error_msg)
            }
        ]
    )

def send_sns(region, Topic, Message, Subject):
    response = None
    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=str(Subject)
        )
        print("response SNS: {}".format(response))
    except Exception as e:
        print('Error SNS: {}'.format(e))
    return response

def get_connection_jdbc(sm_client, connection_key, target=None):
    try:
        get_secret_value_response = sm_client.get_secret_value(
            SecretId=connection_key)
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            print(e)
            #raise e

        eerror = f"Below is the failure details :\n\n{e}"
        eSubjectName = 'Connection Failed'

        if Topic != None:
            send_sns(region_name, Topic.strip(), eerror, eSubjectName[:100])

        if cw_log_group != None:
            put_error_cloudwatch(region_name, cw_log_group.strip(), eerror)

    secretstring = get_secret_value_response['SecretString'].replace('\n', '')

    secret = json.loads(secretstring)
    connection = secret[target]

    return connection
#var

def get_connection():
    conn = None
    try:
        print("Opening Connection")
        conn = psycopg2.connect(host = host, user=username, password=password, database=db_name, port=port) # pragma: allowlist secret
    except Exception as e:
        print (e)
        eerror = f"Below is the failure details :\n\n{e}"
        eSubjectName = 'Connection Failed'

        if Topic != None:
            send_sns(region_name, Topic.strip(), eerror, eSubjectName[:100])

        if cw_log_group != None:
            put_error_cloudwatch(region_name, cw_log_group.strip(), eerror)

        print("ERROR: Unexpected error: Could not connect to RDS instance.")
        raise e
    return conn

def read_postgres_to_df(sql):
    conn = None
    df=pd.DataFrame()
    try:
        conn = get_connection()
        df = pd.read_sql(sql, conn)
    except Exception as e:
        print(e)
    finally:
        if(conn is not None ):
            print("Closing Connection")
            conn.close()
    return df

def write_df_to_postgres(df, table_name):
    conn = get_connection()
    cursor = conn.cursor()

    f = io.StringIO()
    df.to_csv(f, index=False, header=False, sep="|")
    f.seek(0)

    sql= "COPY {} FROM STDIN WITH DELIMITER AS '|' NULL AS ''".format(table_name)
    cursor.copy_expert(sql, f)
    cursor.close()
    conn.commit()
    conn.close()

def upsert_to_postgres(df, table_name):
    conn = get_connection()
    cursor = conn.cursor()

    f = io.StringIO()
    df.to_csv(f, index=False, header=False, sep="|")
    f.seek(0)
    if table_name == 'fetch_results':
        sql = \
            f"CREATE TABLE {schema}.temp_fetch_results AS TABLE {schema}.fetch_results WITH NO DATA; " \
            f"COPY {schema}.temp_fetch_results FROM STDIN WITH DELIMITER AS '|' NULL AS ''; " \
            f"INSERT INTO {schema}.fetch_results " \
            f"SELECT * " \
            f"FROM {schema}.temp_fetch_results " \
            f"ON conflict (studyid,premiseid,accountid,meterid,channel,rltv_mo,bill_date,meterstart_dt,billstop) " \
            f"DO UPDATE SET " \
            f"  company = EXCLUDED.company, " \
            f"  studypoint = EXCLUDED.studypoint, " \
            f"  customer = EXCLUDED.customer, " \
            f"  accountid = EXCLUDED.accountid, " \
            f"  metertype = EXCLUDED.metertype, " \
            f"  metermtpl = EXCLUDED.metermtpl, " \
            f"  meterstop_dt = EXCLUDED.meterstop_dt, " \
            f"  netmeter = EXCLUDED.netmeter, " \
            f"  spi_flg = EXCLUDED.spi_flg, " \
            f"  kwh = EXCLUDED.kwh, " \
            f"  study_channel_flg = EXCLUDED.study_channel_flg, " \
            f"  goodintvper = EXCLUDED.goodintvper, " \
            f"  badintvper = EXCLUDED.badintvper, " \
            f"  interpolper = EXCLUDED.interpolper, " \
            f"  updated_dt = EXCLUDED.updated_dt, " \
            f"  process_run_date = EXCLUDED.process_run_date, " \
            f"  job_run_id = EXCLUDED.job_run_id; " \
            f"DROP TABLE {schema}.temp_fetch_results; "

    elif table_name == 'error':
        sql = \
            f"CREATE TABLE {schema}.temp_error AS TABLE {schema}.error WITH NO DATA; " \
            f"COPY {schema}.temp_error FROM STDIN WITH DELIMITER AS '|' NULL AS ''; " \
            f"INSERT INTO {schema}.error " \
            f"SELECT * " \
            f"FROM {schema}.temp_error " \
            f"ON conflict (studyid,premiseid,rltv_mo,errormessage,updated_dt) " \
            f"DO UPDATE SET " \
            f"  errorcode = EXCLUDED.errorcode, " \
            f"  process = EXCLUDED.process, " \
            f"  studypoint = EXCLUDED.studypoint, " \
            f"  process_run_date = EXCLUDED.process_run_date, " \
            f"  job_run_id = EXCLUDED.job_run_id; " \
            f"DROP TABLE {schema}.temp_error; "
    else:
        print(f"Upsert procedure not set up for {table_name}")
        return
    cursor.copy_expert(sql, f)
    cursor.close()
    conn.commit()
    conn.close()

def update_etl_backdated(study, day, val_dt, val_id, rltv_mo):
    print(study)
    conn = get_connection()
    cursor = conn.cursor()

    sql = f"UPDATE {schema}.etl_backdated SET validation_run_date = {val_dt}, " \
                                            f"validation_run_id = '{val_id}', " \
                                            f"last_process_day = to_date('{day}', 'YYYY-MM-DD') " \
          f"WHERE studyid = '{study}' and rltv_mo = {rltv_mo}"
    cursor.execute(sql)
    cursor.close()
    conn.commit()
    conn.close()

def update_study_to_reprocess(study, val_dt, rltv_mo):
    print(study)
    conn = get_connection()
    cursor = conn.cursor()

    sql = f"UPDATE {schema}.study_to_reprocess " \
          f"SET validation_run_date = {val_dt} " \
          f"WHERE studyid = '{study}' and rltv_mo = {rltv_mo} and validation_run_date is NULL"
    cursor.execute(sql)
    cursor.close()
    conn.commit()
    conn.close()

def delete_old_records(table, studies, rltv_mo):
    if len(studies) == 1:
        studies = "(\'" + str(studies[0]) + "\')"
    else:
        studies = tuple(studies)

    conn = get_connection()
    cursor = conn.cursor()

    sql = f"delete " \
          f"from {schema}.{table} " \
          f"where studyid in {studies} " \
          f"and rltv_mo = {rltv_mo};"
    print(sql)

    cursor.execute(sql)
    cursor.close()
    conn.commit()
    conn.close()

def get_previous_mo(mo):
    '''function to get previous rltv_mo, given integer like: 202107
    '''
    mo_prior = mo - 1
    if mo_prior % 100 == 0:
        mo_prior = mo_prior - 100 + 12
    return mo_prior


def read_ALR(tables, rltv_mo = 0, premises = (), company = ''):
    '''
    :param tables: a list of which tables to pull from ALR
    :param rltv_mo: optional to filter for only given relative month
    :param premises: optional to filter for only given premises
    :return: ALR Tables: studypremise, study, fetch_results, premise_usage, variables, active_premises, etl_backdated
    '''
    studypremise = study = fetch_results = premise_usage = variables = active_premises = etl_backdated = error = \
        study_to_reprocess = pd.DataFrame()

    print(f"Reading in ALR data" + ((" for " + str(rltv_mo)) if rltv_mo != 0 else ""))

    sql = f"select * \
    from {schema}.study_premise p \
    left join (select studyid, stratumid, ratecodes from {schema}.study) s \
    on (p.studyid = s.studyid and p.stratumid = s.stratumid) \
    where p.deleted_flg is distinct from True \
    order by p.studyid, p.studypoint::float"

    if 'study_premise' in tables:
        studypremise = read_postgres_to_df(sql)
        studypremise = studypremise.loc[:, ~studypremise.columns.duplicated()]
        studypremise.studypoint = studypremise.studypoint.astype(float)
        studypremise.studyid = studypremise.studyid.str.upper()
        print("study_premise loaded")

    sql2 = f"select studyid, stratumid, startdate, enddate, stratumkwh, fetchtype, ratecodes::_text, channels, backdated_flag \
        from {schema}.study \
        where deleted_flg is distinct from True"
    if 'study' in tables:
        study = read_postgres_to_df(sql2)
        study.enddate = np.where(study.enddate.isna(), pd.Timestamp.max.date(), study.enddate)
        study.studyid = study.studyid.str.upper()
        print("study loaded")

    if len(premises) > 0:
        sql3 = f"select * from {schema}.fetch_results where premiseid in {premises} and company in {company}"
    else:
        sql3 = f"select * from {schema}.fetch_results where rltv_mo = {rltv_mo}"
    if 'fetch_results' in tables:
        fetch_results = read_postgres_to_df(sql3)
        fetch_results.studypoint = fetch_results.studypoint.astype(float)
        print("fetch_results loaded")

    if len(premises) > 0:
        sql4 = f"select * from {schema}.premise_usage where premiseid in {premises} and company in {company}"
    else:
        sql4 = f"select * from {schema}.premise_usage where rltv_mo = {rltv_mo}"
    if 'premise_usage' in tables:
        premise_usage = read_postgres_to_df(sql4)
        premise_usage.studypoint = premise_usage.studypoint.astype(float)
        print("premise_usage loaded")

    sql5 = f"select * from {schema}.variable where deleted_flg is distinct from True"
    if 'variable' in tables:
        variables = read_postgres_to_df(sql5)
        print("variables loaded")

    sql6 = f"select * from {schema}.active_premise where rltv_mo = {rltv_mo}"
    if 'active_premises' in tables:
        active_premises = read_postgres_to_df(sql6)
        active_premises.studypoint = active_premises.studypoint.astype(float)
        active_premises.current_flg = active_premises.current_flg.astype(bool)
        active_premises.current_flg = np.where(active_premises.current_flg == True, 1, 0)
        print("active_premises loaded")

    sql7 = f"select * from {schema}.etl_backdated"
    if 'etl_backdated' in tables:
        etl_backdated = read_postgres_to_df(sql7)
        print("etl_backdated loaded")

    sql8 = f"select * from {schema}.error"
    if 'error' in tables:
        error = read_postgres_to_df(sql8)
        print("error loaded")

    sql9 = f"select * from {schema}.study_to_reprocess"
    if 'study_to_reprocess' in tables:
        study_to_reprocess = read_postgres_to_df(sql9)
        print("study_to_reprocess loaded")

    print("Done")
    return studypremise, study, fetch_results, premise_usage, variables, active_premises, etl_backdated, error, \
           study_to_reprocess

region_name = 'us-east-1'
sm_client = boto3.client('secretsmanager', region_name=region_name)

options = parse_arguments(sys.argv)
sm_name = options.get('sm_name')
Topic = options.get('sns_topic') or None
cw_log_group = options.get('cw_log_group') or None
connection_key = sm_name.strip() # '2FNV-LO174-ALR-sm' # DEV  #connection_key = '2FPV-LO174-ALR-sm' # PROD
print('connection_key')
print(connection_key)
if Topic != None: Topic = Topic.strip()
if cw_log_group != None: cw_log_group = cw_log_group.strip()

connection = get_connection_jdbc(sm_client, connection_key, 'alr_validation')

host = connection['url']
username = connection['username']
password = connection['password'] # pragma: allowlist secret
db_name = connection['db_name']
port = connection['port']
schema = connection['schema']
#schema = 'public'
#print(schema)

# Set values from variables table in ALR
variables = read_ALR(['variable'])[4]
#missing_perc_thresh = float(variables[variables.variableid == 'INTDATAFIRST'].value.item())
switch_perc_thresh = float(variables[variables.variableid == 'INTDATASECOND'].value.item())
missing_perc_thresh = float(variables[variables.variableid == 'DRO'].value.item()[:-1])/100
bill_diff_thresh = float(variables[variables.variableid == 'BILLCOMP'].value.item())
aumonth = int(variables[variables.variableid == 'AUMONTH'].value.item())
switch_trig_day = int(variables[variables.variableid == 'SWITCHDAYOFMONTH'].value.item())

def get_error_message(errorcode, kwh = 0, billkwh = 0, months = 0, bad_intv = 0, meter = "", metertype = "",
                      channel = 0, change = "", old_value = "", new_value = "", startstop = "", date = "",
                      ratecode = "", ratecodes = "", min_kwh = 0, max_kwh = 0, stratum = "", meterstop = "",
                      billstop = ""):
    '''
    Given an errorocode, fills appropriate error message using other given parameters
    :return: The error message as a string
    '''

    old_value = [old_value if isinstance(old_value, list) else [" " if pd.isna(old_value) else old_value][0]][0]
    new_value = [new_value if isinstance(new_value, list) else [" " if pd.isna(new_value) else new_value][0]][0]
    old_value = [round(old_value) if isinstance(old_value, (int, float)) else old_value][0]
    new_value = [round(new_value) if isinstance(new_value, (int, float)) else new_value][0]
    old_value = [f"'{old_value}'" if isinstance(old_value, (str)) else old_value][0]
    new_value = [f"'{new_value}'" if isinstance(new_value, (str)) else new_value][0]

    max_kwh = ["inf" if max_kwh==9999999999 else round(float(max_kwh))][0]

    ratecode = ["' '" if ratecode=='-1' else ratecode][0]

    # Map error codes to error messages
    error_messages_map = {
        "BILLDATA":       "No bill data could be received for the premise during the current cycle.",
        "DIFFBILLCOMP":  f"Interval cut ({round(kwh,2)} kwh) is outside the {bill_diff_thresh*100}% threshold when compared to billed usage ({billkwh} kwh).",
        "NULLBILL":       "Cannot perform bill comparison because billed usage is 0 kwh.",
        "AUMONTH":       f"Only {months} months are available to calculate monthly average usage, less than the needed {aumonth} months.",
        "BADINTV":       f"The percent of bad intervals ({round(bad_intv*100,1)}%) is outside of the {missing_perc_thresh*100}% threshold.",
        "SYS":            "A system error occurred.",
        "NODATA":         "Interval data could not be retrieved for at least one channel.",
        "INCOMPINTVS":   f"Incomplete intervals fetched. The last meter fetched stops at {meterstop}, but the bill runs until {billstop}.",
        "DUPROWS":       f"Interval data excluded due to duplicate rows in net-meter data.",
        "SPI":           f"Inconsistent SPIs in interval cut for meter {meter} channel {round(channel)}.",
        "SPILENGTH":     f"SPI longer than 60 minutes for meter {meter} channel {round(channel)}.",
        "PREMISE":       f"Premise data change: {change} changed from {old_value} to {new_value}.",
        "INFORMATIONAL": f"Master data change: {change} changed from {old_value} to {new_value}.",
        "METERCHANGE":   f"Meter {meter} (type {metertype}) {startstop} on {date}.",
        "PURESTUDY":      "Net meter used as studypoint for pure study.",
        "RATECODE":      f"Premise ratecode ({ratecode}) is outside of the study ratecodes ({str(ratecodes)[1:-1]}).",
        "STRATUM":       f"Average monthly usage ({round(kwh, 2)} kwh) is outside of the limits ({round(float(min_kwh))}-{max_kwh} kwh) for the studypoint's stratum ({stratum})."
    }
    return error_messages_map[errorcode]

# Map error codes to processes (multiple codes per process, potentially)
error_process_map      = dict.fromkeys(["SPI", "BADINTV", "DIFFBILLCOMP", "NULLBILL",
                                        "AUMONTH", "PURESTUDY", "SPILENGTH",
                                        "INCOMPINTVS"],                               'Interval Data Quality')
error_process_map.update(dict.fromkeys(["PREMISE", "INFORMATIONAL", "METERCHANGE"],   'Master Data'))
error_process_map.update(dict.fromkeys(["NODATA", "DUPROWS"],                         'Interval Data Fetch'))
error_process_map.update(dict.fromkeys(["BILLDATA", "RATECODE", "STRATUM"],           'Automatic Switching'))
# SYS errors won't be mapped


def append_error_df(error_df, rows_to_log, errorcode):
    '''
    Takes error dataframe as input, appends to it based on the given errorcode and a dataframe of rows_to_log
    :return: error_df
    '''
    rows_to_log['errorcode'] = errorcode

    # BADINTV Errors:
    if errorcode == "BADINTV":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], bad_intv=x['badintvper']), axis=1)

    # SPI/SPILENGTH Errors:
    elif (errorcode == "SPI") | (errorcode == "SPILENGTH"):
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], meter=x['meterid'], channel=x['channel']), axis=1)

    # NODATA/DUPROWS Errors
    elif (errorcode == "NODATA") | (errorcode == "DUPROWS"):
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode']), axis=1)

    # DIFFBILLCOMP Errors:
    elif errorcode == "DIFFBILLCOMP":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], kwh=x['kwh'], billkwh=x['billkwh']), axis=1)

    # INCOMPINTVS Errors:
    elif errorcode == "INCOMPINTVS":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], meterstop=x['meterstop_dt'], billstop=x['billstop']), axis=1)

    # AUMONTH Errors:
    elif errorcode == "AUMONTH":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], months=x['num_months_monthlyavg']), axis=1)

    # PREMISE/INFORMATIONAL Errors:
    elif (errorcode == "PREMISE") | (errorcode == "INFORMATIONAL"):
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], change=x['change'], old_value=x['change_old'],
                                        new_value=x['change_new']), axis=1)

    # METERCHANGE Errors
    elif errorcode == "METERCHANGE":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], meter=x['meterid'], metertype=x['metertype'],
                                        startstop=x['startstop'], date=x['startstopdate']), axis=1)
    # RATECODE Errors
    elif errorcode == "RATECODE":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], ratecode=x['ratecode'], ratecodes=x['ratecodes']), axis=1)

    # STRATUM Errors
    elif errorcode == "STRATUM":
        rows_to_log['errormessage'] = rows_to_log.apply(
            lambda x: get_error_message(x['errorcode'], kwh=x['avgmonthlykwh'], min_kwh=x['min_kwh'],
                                        max_kwh=x['max_kwh'], stratum=x['stratumid']), axis=1)

    # All other errors:
    else:
        rows_to_log['errormessage'] = rows_to_log.apply(lambda x: get_error_message(x['errorcode']), axis=1)

    rows_to_log['process'] = error_process_map[errorcode]
    rows_to_log['updated_dt'] = np.nan
    return error_df.append(rows_to_log)


def compare_err_cols(x, err_cols):
    '''Function to compare columns between old and new. err_cols = list of columns for premise errors or info errors
    '''
    changes = []

    for col in err_cols:
        if x[col+'_new'] != x[col+'_old']:
                 changes.append(col)
    return changes


def move_negative_index_to_bottom(x, df):
    return np.where(x<0, len(df)+x, x)


def get_stratumid(studystratum, kwh, study):
    '''
    :param studystratum: The study table grouped by study with stratumkwh as a list
    :param kwh: Average monthly usage to check
    :param study: Study to check
    :return: stratumid
    '''

    # Extract the upperbound stratum kwhs for the given study
    maxkwhs = studystratum[studystratum.studyid == study].maxkwhs.values[0]

    # Check which stratum limits the given kwh is greater than, get the index
    uppers = [i for i in range(len(maxkwhs)) if maxkwhs[i] > kwh]

    # The minimum of those is the index of the right stratum
    strat_i = [min(uppers) if (len(uppers) > 0) else 0][0]

    # Use studystratum to get the stratumid
    return studystratum[studystratum.studyid == study].stratums.str[strat_i].values[0]

########################################################################################################################
def automatic_switching(rltv_mo, studyids = [], process_run_date = 0, job_run_id = ''):
    '''
    :param rltv_mo: Switch for the given rltv_mo
    :param studyids: A list of studies (either current studies for daily, or not yet processed and backdated for backdated)
    '''

    print(f"Starting automatic switching for {rltv_mo}")
    print(studyids)

    studypremise, study, fetch_results, premise_usage = read_ALR(['study_premise', 'study', 'fetch_results',
                                                                  'premise_usage'],rltv_mo)[0:4]

    # If reading from csv's:
    # premise_usage = pd.read_csv('premise_usage.csv')
    # if os.path.isfile('active_premise.csv'):
    #     active_premises_old = pd.read_csv('active_premise.csv')
    #     active_premises_old = active_premises_old[active_premises_old.rltv_mo == get_previous_mo(rltv_mo)]
    # else:
    #     active_premises_old = pd.DataFrame(columns = list(active_premises_old))

    # To only switch for the given study/studies, filter fetch_results/premise_usage/studypremise
    if len(studyids) > 0:
        fetch_results = fetch_results[fetch_results.studyid.isin(studyids)]
        premise_usage = premise_usage[premise_usage.studyid.isin(studyids)]
        studypremise = studypremise[studypremise.studyid.isin(studyids)]

    # We'll also filter INTONLY studies from studypremise so that we don't switch on them
    studypremise = studypremise[~studypremise.studyid.str.contains('INTONLY')]

    error = read_ALR(['error'],rltv_mo)[7]
    active_premises_old = read_ALR(['active_premises'], get_previous_mo(rltv_mo))[5]

    fetch_results = fetch_results[fetch_results.rltv_mo == rltv_mo]
    premise_usage = premise_usage[premise_usage.rltv_mo == rltv_mo]

    '''
    Multiple Bill Handling (Re-billed, not two accounts)
    --------------------------------------------------------------------------------------------------------------------
    '''
    # Get rid of old bill in premise_usage if bill_date is not most recent for premise

    print("Removing old bills for accounts that were re-billed")

    # Group by premise/account/study to find premises/accounts that were billed more than once
    premise_bill_cnt = premise_usage.groupby(['premiseid', 'billstop', 'studyid']).count()[
        'bill_date'].reset_index().rename(columns={'bill_date': 'bill_cnt'})
    premise_bill_cnt = premise_bill_cnt[premise_bill_cnt.bill_cnt > 1].merge(
        premise_usage[['premiseid', 'billstop', 'accountid', 'studyid', 'bill_date']], how='left',
        on=['premiseid', 'billstop', 'studyid'])

    # Group premise_bill_cnt, get minimum bill_date
    # premise_bill_cnt = premise_bill_cnt.groupby(['studyid', 'premiseid', 'accountid']).min()[
    #     ['bill_date']].reset_index()
    premise_bill_cnt_max = premise_bill_cnt.groupby(['studyid', 'premiseid', 'billstop']).max()[
        ['bill_date']].reset_index()
    ix1 = premise_bill_cnt.set_index(['premiseid', 'billstop', 'studyid', 'bill_date']).index
    ix2 = premise_bill_cnt_max.set_index(['premiseid', 'billstop', 'studyid', 'bill_date']).index
    premise_bill_cnt = premise_bill_cnt[~ix1.isin(ix2)].reset_index()

    # Filter old bills out of premise_usage
    i1 = premise_usage.set_index(['premiseid', 'billstop', 'studyid', 'bill_date']).index
    i2 = premise_bill_cnt.set_index(['premiseid', 'billstop', 'studyid', 'bill_date']).index
    premise_usage = premise_usage[~i1.isin(i2)]

    # Keep track of studypoints that fail one of the checks and would trigger switching
    bad_studypoints = pd.DataFrame()

    error_df = pd.DataFrame(
        columns=['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id'])

    '''
    Ratecode Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # Check whether or not ratecode is in study ratecodes
    # If there is any change in ratecode, it should be logged as error when validations are done on fetch day
    # But ratecode can change, but still be within the rate class for the study, so this separate check is required

    print("Performing Ratecode Check")

    # Merge premise_usage to study to get the ratecodes that a premise should have for that study
    # Then filter for premises whose ratecode is not in the study ratecodes
    premise_ratecodes = premise_usage.merge(study[['studyid', 'ratecodes']], how='left', on='studyid')
    #premise_ratecodes.ratecode = premise_ratecodes.ratecode.astype(pd.Float32Dtype()).astype(pd.Int32Dtype())
    premise_ratecodes.ratecode = premise_ratecodes.ratecode.fillna('-1')

    def check_ratecodes(row):
        row.ratecode = [str(row.ratecode) if isinstance(row.ratecode, (int, float)) else row.ratecode][0]
        return row.ratecode not in row.ratecodes

    bad_studypoints = bad_studypoints.append(
        premise_ratecodes[premise_ratecodes.apply(lambda x: check_ratecodes(x), axis=1)][['studyid', 'studypoint']])

    # Write to error table where ratecode is bad
    error_df_append = premise_ratecodes[premise_ratecodes.apply(lambda x: check_ratecodes(x), axis=1)][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'ratecode', 'ratecodes']]
    error_df_append.ratecodes = error_df_append.ratecodes.astype(str)
    error_df_append = error_df_append.drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "RATECODE")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]
    '''
    Pure Study Check
    --------------------------------------------------------------------------------------------------------------------

    '''

    print("Performing Pure Study Check")

    bad_studypoints = bad_studypoints.append(error[error.errorcode == 'PURESTUDY'][['studyid', 'studypoint']])

    '''
    No Data Check
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Performing No Data Check")

    # Filter old bills out of fetch_results, based on what we set for premise_usage
    fetch_results2 = fetch_results.merge(premise_usage[['studyid', 'premiseid', 'accountid', 'rltv_mo', 'bill_date',
                                                        'billstop', 'billkwh']], how='left',
                                         on=['studyid', 'premiseid', 'accountid', 'rltv_mo', 'bill_date', 'billstop'])
    fetch_results = fetch_results2[~(fetch_results2.billkwh.isna() & (fetch_results2.studyid != 'BILLONLY'))]

    # Filter where a channel is missing kwh in fetch_results
    bad_studypoints = bad_studypoints.append(fetch_results[fetch_results.kwh.isna()][['studyid', 'studypoint']])

    '''
    Missing Interval Check
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Performing Missing Interval Check")

    # Filter for studypoints that are missing greater than x% of intervals after interpolation is attempted:
    bad_studypoints = bad_studypoints.append(
        premise_usage[premise_usage.badintvper > switch_perc_thresh][['studyid', 'studypoint']])

    '''
    Incomplete Intervals Check
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Performing Incomplete Intervals Check")

    bad_studypoints = bad_studypoints.append(error[error.errorcode == 'INCOMPINTVS'][['studyid', 'studypoint']])

    '''
    Stratum Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # Only for premise studies

    print("Performing Stratum Check")

    # Calculate min and max kwh for each stratum in study
    study2 = study.sort_values(['studyid', 'stratumid'])
    study2['min_kwh'] = study2.stratumkwh.shift(1).fillna(0)
    study2.min_kwh = np.where(((study2.min_kwh == 'inf') | (study2.min_kwh == 'INF')), 0, study2.min_kwh)
    study2.stratumkwh = np.where(((study2.stratumkwh == 'inf') | (study2.stratumkwh == 'INF')), 9999999999, study2.stratumkwh)
    study2 = study2.rename(columns={'stratumkwh': 'max_kwh'})

    # Join study min and max stratum kwh to studypremise
    studypremise2 = \
    studypremise.merge(study2[['studyid', 'stratumid', 'min_kwh', 'max_kwh']], how='left',
                       on=['studyid', 'stratumid'])[['studyid','studypoint','stratumid','min_kwh','max_kwh']]

    # Join studypremise with the premise_usage
    premise_studypoints = studypremise2.merge(premise_usage, how='left', on=['studyid', 'studypoint'])
    premise_studypoints_nobill = premise_studypoints[premise_studypoints.bill_date.isna()]
    premise_studypoints = premise_studypoints[~premise_studypoints.bill_date.isna()]

    # Check whether a premise's avgmonthlykwh usage is within the study stratum
    def check_stratum(row):
        '''Returns True/False for whether avgmonthlykwh is in stratum
        '''
        return (row.avgmonthlykwh >= float(row.min_kwh)) & (row.avgmonthlykwh < float(row.max_kwh))

    if len(premise_studypoints) > 0: # Only do this if there are premise studies
        bad_studypoints = bad_studypoints.append(
            premise_studypoints[~premise_studypoints.apply(lambda x: check_stratum(x), axis=1)][['studyid', 'studypoint']])

        # Write to error table where avgmonthlykwh exceeds stratum max/min
        error_df_append = premise_studypoints[~premise_studypoints.apply(lambda x: check_stratum(x), axis=1)][
            ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'avgmonthlykwh', 'min_kwh', 'max_kwh',
             'stratumid']].drop_duplicates()

        # Send rows to append to function, if any available
        if len(error_df_append) > 0:
            error_df = append_error_df(error_df, error_df_append, "STRATUM")[
                ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id']]

    '''
    No Bill Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # Only for premise studies
    # Look at whether a bill is there when we do switching

    print("Performing No Bill Check")

    # premise_studypoints_nobill created above in stratum check, by joining premise_usage to studypremise, filtering for nan
    bad_studypoints = bad_studypoints.append(premise_studypoints_nobill[['studyid', 'studypoint']])

    # Log error if no bill can be retrieved
    error_df_append = premise_studypoints_nobill[['studyid','rltv_mo','studypoint']].merge(
        studypremise[['studyid','studypoint','premiseid']],
        how = 'left',
        on = ['studyid','studypoint']).drop_duplicates()
    error_df_append.rltv_mo = rltv_mo

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
       error_df = append_error_df(error_df, error_df_append, "BILLDATA")[
           ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
            'process_run_date', 'job_run_id']]

    bad_studypoints = bad_studypoints.drop_duplicates()
    bad_studypoints.studypoint = bad_studypoints.studypoint.astype(float)

    '''
    Bill Comparison
    --------------------------------------------------------------------------------------------------------------------
    '''
    # Not switching based off bills in phase1, just writing error (when validated)

    '''
    Multiple Accounts Handling
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Aggregating Premises with Multiple Accounts")

    # Group premise_usage by premise/study to get the min bill start, max bill stop if there are multiple accounts per premise
    # Also aggregate kwh and billkwh
    premise_usage_grouped = premise_usage.groupby(['studyid', 'premiseid']).agg(
        {'billstart': 'min'}).reset_index().rename(columns={'billstart': 'startdt'})
    premise_usage_grouped2 = premise_usage.groupby(['studyid', 'premiseid']).agg(
        {'billstop': 'max'}).reset_index().rename(columns={'billstop': 'stopdt'})
    premise_usage_aggregated = premise_usage.groupby(['studyid','premiseid']).sum()[['kwh', 'billkwh']].reset_index()

    # Add startdt / stopdt / kwh / billkwh back to premise_usage as startdt / stopdt
    premise_usage_1 = premise_usage.merge(premise_usage_grouped, how='left', on=['studyid', 'premiseid'])
    premise_usage_1 = premise_usage_1.merge(premise_usage_grouped2, how='left', on=['studyid', 'premiseid'])
    premise_usage_1 = premise_usage_1.drop(columns=['kwh','billkwh']).merge(
        premise_usage_aggregated, how='left', on = ['studyid', 'premiseid'])

    # Filter premise_usage to only keep bill with greatest bill date (i.e. the one with the max billstop, or billstop = stopdt)
    premise_usage_1 = premise_usage_1[premise_usage_1.billstop == premise_usage_1.stopdt]

    # premise_usage_1 now represents premise_usage "aggregated" at premise level if > 1 account per premise in a rltv_mo

    # All rate studies should have current_flg = 1, no "switching"
    # '''
    # Switching for Rate Studies
    # --------------------------------------------------------------------------------------------------------------------
    # '''
    #
    # print("Performing Automatic Switching for Rate Studies")
    #
    # # Create current flag, set to false for bad studypoints
    # bad_studypoints['current_flg'] = 0
    #
    # # Merge to premise usage for all points that are in a retecode study
    # ratestudy = study[study.fetchtype.str.upper() == 'RATESTUDY'].copy()
    # active_premises_rate = premise_usage_1[premise_usage_1.studyid.isin(ratestudy.studyid)].merge(
    #     bad_studypoints, how='left', on=['studyid', 'studypoint'])
    #
    # if len(active_premises_rate) > 0:
    #     # The points that weren't in bad_studypoints are active
    #     active_premises_rate.current_flg = active_premises_rate.current_flg.fillna(1)
    #
    #     # Group the study table by studyid so that stratums and corresponding upperbound stratum kwh are concatenated to lists
    #     study2.max_kwh = pd.to_numeric(study2.max_kwh)
    #     studystratum = study2.groupby('studyid').apply(lambda x: [list(x['stratumid']), list(x['max_kwh'])]).apply(
    #         pd.Series).reset_index().rename(columns={0: 'stratums', 1: 'maxkwhs'})
    #
    #     # Get the corresponding stratum for each premise in active_premises_rate
    #     active_premises_rate['stratumid'] = active_premises_rate.apply(
    #         lambda x: get_stratumid(studystratum, x['avgmonthlykwh'], x['studyid']), axis=1)
    #
    #     active_premises_rate = active_premises_rate[[
    #         'studyid',  # PK
    #         'company',
    #         'rltv_mo',  # PK
    #         'premiseid',  # PK
    #         'customer',
    #         'zipcode',
    #         'wc_dist',
    #         'kwh',
    #         'startdt',
    #         'stopdt',
    #         'bill_date',
    #         'billkwh',
    #         'studypoint',
    #         'stratumid',
    #         'current_flg'
    #     ]]
    #     active_premises_rate['prior_alt'] = np.nan

    # INTONLY Studies will be treated as if they are ratestudies (no switching, current_flg = True), so we'll add them
    # to active_premises_rate
    ratestudy = study[study.fetchtype.str.upper() == 'RATESTUDY'].copy()
    active_premises_rate = premise_usage_1[premise_usage_1.studyid.isin(ratestudy.studyid) |
                                           premise_usage_1.studyid.str.contains('INTONLY')]

    # Group the study table by studyid so that stratums and corresponding upperbound stratum kwh are concatenated to lists
    study2.max_kwh = pd.to_numeric(study2.max_kwh)
    studystratum = study2.groupby('studyid').apply(lambda x: [list(x['stratumid']), list(x['max_kwh'])]).apply(
        pd.Series).reset_index().rename(columns={0: 'stratums', 1: 'maxkwhs'})

    # Get the corresponding stratum for each premise in active_premises_rate
    if len(active_premises_rate) > 0:
        active_premises_rate['stratumid'] = active_premises_rate.apply(
            lambda x: get_stratumid(studystratum, x['avgmonthlykwh'], x['studyid']), axis=1)
    else:
        active_premises_rate['stratumid'] = np.nan

    active_premises_rate = active_premises_rate[[
        'studyid',  # PK
        'company',
        'rltv_mo',  # PK
        'premiseid',  # PK
        'customer',
        'zipcode',
        'wc_dist',
        'kwh',
        'startdt',
        'stopdt',
        'bill_date',
        'billkwh',
        'studypoint',
        'stratumid'
    ]]
    active_premises_rate['current_flg'] = 1
    active_premises_rate['prior_alt'] = np.nan


    '''
    Switching for Premise Studies
    --------------------------------------------------------------------------------------------------------------------
    '''

    if len(premise_studypoints) > 0: # Only do this if there are premise studies

        print("Performing Automatic Switching for Premise Studies")

        active_premises_prem_old = active_premises_old[~active_premises_old.studyid.isin(ratestudy.studyid)]

        # Merge studypremise with active_premises_prem_old to see which studypoints are active (or set all inactive if first time)
        if len(active_premises_prem_old) > 0:
            studypremise = studypremise.merge(active_premises_prem_old[['studyid', 'studypoint', 'current_flg']],
                                              how='left', on=['studyid', 'studypoint'])
        else:
            studypremise['current_flg'] = 0

        all_points = pd.DataFrame(columns=['studyid', 'studypoint', 'current_flg','prior_alt'])

        # Loop through each study in studypremise
        #for s in studypremise.studyid.unique():
        for s in studyids:
            if s in studypremise.studyid.unique():
                print(s)

            # Loop through all integer studypoints for the study
            for i in studypremise[(studypremise.studyid == s) & (studypremise.studypoint % 1 == 0)].studypoint:
                points = studypremise[(studypremise.studyid == s) &
                                      (studypremise.studypoint >= i) &
                                      (studypremise.studypoint < i + 1)][['studyid', 'studypoint', 'current_flg']].copy()

                if any(points.current_flg == 1):
                    # Keep track of which point was active before swithching (i.e. the prior_alt)
                    prior_alt = points.loc[points.current_flg == 1].studypoint.item()

                    # Sort points so that the old active point is on top
                    points['new'] = points.index - points[points.current_flg == 1].index[0]

                    points.new = points.new.apply(lambda x: move_negative_index_to_bottom(x, points))
                    points = points.sort_values('new').drop('new', axis=1)
                else:
                    prior_alt = np.nan

                # Filter points for not in badstudypoints
                i1 = points.set_index(['studyid', 'studypoint']).index
                i2 = bad_studypoints.set_index(['studyid', 'studypoint']).index
                points = points[~i1.isin(i2)].reset_index()

                # Set top of points to active
                if len(points) > 0:
                    points.iloc[0, 3] = 1

                # Make a column to keep track of the prior_alt
                # Only fill for active point if active point changed (i.e. active studypoint != prior studypoint)
                points['prior_alt'] = np.where((points.current_flg == 1) & (points.studypoint != prior_alt), prior_alt,
                                               np.nan)

                # Add to dataframe of all points
                all_points = all_points.append(points.drop(columns='index'))

        # Merge all_points to studypremise, fillna current_flg as 0 (these were the points filtered out as badstudypoints)
        studypremise_new = studypremise.drop(columns='current_flg').merge(all_points, how='left', on=['studyid', 'studypoint'])
        studypremise_new.current_flg = studypremise_new.current_flg.fillna(0)

        # # Merge to premise_usage to get company (or any other premise attributes if needed later)
        # studypremise_new = studypremise_new.merge(premise_usage_1[['studyid', 'studypoint', 'company']], how='left',
        #                                           on=['studyid', 'studypoint'])

        premise_usage_1.studypoint = premise_usage_1.studypoint.astype(float)
        active_premises_prem = studypremise_new[
            ['premiseid', 'studyid', 'studypoint', 'stratumid', 'company', 'current_flg', 'prior_alt']].merge(
            premise_usage_1[['studyid', 'studypoint', 'rltv_mo', 'customer', 'zipcode', 'wc_dist', 'kwh', 'bill_date',
                             'billkwh', 'startdt', 'stopdt']],
            how='left', on=['studyid', 'studypoint'])

        if len(studyids) > 0:
            active_premises_prem = active_premises_prem[active_premises_prem.studyid.isin(studyids)]

        active_premises = active_premises_prem.append(active_premises_rate)
    else:
        active_premises = active_premises_rate

    active_premises['updated_dt'] = np.nan
    active_premises['process_run_date'] = process_run_date
    active_premises['job_run_id'] = job_run_id
    active_premises = active_premises[[
        'studyid',  # PK
        'stratumid',
        'company',
        'rltv_mo',  # PK
        'premiseid',  # PK
        'customer',
        'zipcode',
        'wc_dist',
        'kwh',
        'startdt',
        'stopdt',
        'bill_date',
        'billkwh',
        'studypoint',
        'prior_alt',
        'current_flg',
        'updated_dt',
        'process_run_date',
        'job_run_id'
    ]]

    active_premises.rltv_mo = active_premises.rltv_mo.fillna(rltv_mo)

    '''
    Output
    --------------------------------------------------------------------------------------------------------------------
    '''

    error_df.process_run_date = process_run_date
    error_df.job_run_id = job_run_id

    # Make sure all have same updated_dt and drop duplicates
    active_premises = active_premises.drop_duplicates()
    active_premises['updated_dt'] = datetime.now(pytz.timezone("US/Eastern"))
    error_df = error_df.drop_duplicates()
    error_df['updated_dt'] = datetime.now(pytz.timezone("US/Eastern"))

    print("Writing Tables to ALR")
    #active_premises.stratumid = active_premises.stratumid.astype(pd.Int32Dtype())
    active_premises.rltv_mo = active_premises.rltv_mo.astype(pd.Int32Dtype())
    active_premises.zipcode = active_premises.zipcode.astype(pd.Int32Dtype())
    active_premises.wc_dist = active_premises.wc_dist.astype(pd.Int32Dtype())
    active_premises.current_flg = active_premises.current_flg.astype(int)
    write_df_to_postgres(active_premises, table_name=f'{schema}.active_premise')

    error_df.rltv_mo = error_df.rltv_mo.astype(pd.Int32Dtype())
    error_df.premiseid = error_df.premiseid.astype(pd.Int32Dtype())
    error_df.errormessage = error_df.errormessage.apply(lambda x: x[0:255])
    write_df_to_postgres(error_df, table_name=f'{schema}.error')

    # Or write table to csvs
    # if os.path.isfile('active_premise.csv'):
    #     active_premises.to_csv('active_premise.csv', index=False, mode='a', header=False)
    # else:
    #     active_premises.to_csv('active_premise.csv', index=False)
    #
    # if os.path.isfile('error.csv'):
    #     error_df.to_csv('error.csv', index=False, mode='a', header=False)
    # else:
    #     error_df.to_csv('error.csv', index=False)

    print(f"Finished automatic switching for {rltv_mo}.")


########################################################################################################################
def validations(df2, process_run_date = 0, job_run_id = '', rltv_mo = 0, studyids = []):

    company = df2.company.unique()
    if len(company) == 1:
        company = "(\'" + str(company[0]) + "\')"
    else:
        company = tuple(company)

    premises = df2.premiseid.unique()
    if len(premises) == 1:
        premises = "(\'" + str(premises[0]) + "\')"
    else:
        premises = tuple(premises)

    studypremise, study, fetch_results_old, premise_usage_old = read_ALR([
        'study_premise', 'study', 'fetch_results', 'premise_usage'],
        premises=premises, company=company)[0:4]

    # Limit to only active studies
    if len(studyids) > 0:
        study = study[study.studyid.isin(studyids)]
        studypremise = studypremise[studypremise.studyid.isin(studyids)]


    # If reading from csv's only:
    # if os.path.isfile('fetch_results.csv'):
    #     fetch_results_old = pd.read_csv('fetch_results.csv')
    # else:
    #     fetch_results_old = pd.DataFrame(columns = list(fetch_results_old))
    #
    # if os.path.isfile('premise_usage.csv'):
    #     premise_usage_old = pd.read_csv('premise_usage.csv')
    # else:
    #     premise_usage_old = pd.DataFrame(columns = list(premise_usage_old))

    print("Building dataframes for checks")

    ## Separate df2 into df2 for ratestudies and df2 for premise studies (a few premises overlap)

    # Count number of channels per premise/account, add as column to df2
    df2 = df2.merge(df2.groupby(['premiseid', 'accountid']).count()['channel'].reset_index().rename(
        columns={'channel': 'channel_cnt'}),
                    how='left', on=['premiseid', 'accountid'])

    # Count number of channels per premise/meterid, add as column to df2
    df2 = df2.merge(df2.groupby(['premiseid', 'meterid']).count()['channel'].reset_index().rename(
        columns={'channel': 'channel_cnt_meter'}),
                    how='left', on=['premiseid', 'meterid'])

    # Count number of net meters per premise/account, add as column to df2
    df2_nm_cnt = df2.groupby(['premiseid', 'accountid']).sum()['netmeter'].reset_index().rename(
        columns={'netmeter': 'nm_cnt'})
    df2 = df2.merge(df2_nm_cnt[df2_nm_cnt > 0], how='left', on=['premiseid', 'accountid'])

    # Keep track of powerbilling premises
    df2_pb = df2[df2.premiseid.isin(df2[(df2.metertype == 'MULTIPB') | (df2.metertype == 'SOLARN')].premiseid)]
    df2_sst = df2[df2.premiseid.isin(df2[(df2.metertype == 'XXXXXXX')].premiseid)]

    # Make a flag to keep track of premises that have net meter channels but are not billed as net meters
    df2['non_billed_nm'] = 0
    df2.loc[(~df2.premiseid.isin(df2_pb.premiseid)) &
            (df2.channel.isin([2, 4, 9])) &
            (df2.netmeter == 0), 'non_billed_nm'] = 1

    # Duplicate rows where non_billed_nm = 1 and channel = 2. Then change the channel to 1, but flag them as "fake 1s"
    df2['fake_1_flg'] = 0
    duplicate_df2 = df2[(df2.non_billed_nm == 1) & (df2.channel == 2)].copy()
    duplicate_df2.channel = 1.0
    duplicate_df2.fake_1_flg = 1
    # Add these to df2
        # This allows us to make sure a study that has specified channel 1 (i.e. a PURE study) get matched to the "fake 1" channel 2s
    df2 = df2.append(duplicate_df2)


    ## Define premise studies
    # Merge df2 to studypremise on premiseid/company to get the studypoint/study for premise studies
        # Premiseid not necassarily unique between companies
    df2_merge = df2.merge(studypremise[['premiseid', 'studyid', 'company', 'studypoint']], how='left',
                          on=['premiseid', 'company'])

    df2_premisestudy = df2_merge[(~df2_merge.studypoint.isna()) & (df2_merge.channel != 1000)]

    premisestudy_channel = study[(study.fetchtype.str.upper() == 'PREMISE') & (~study.channels.isna())].copy()
    premisestudy = study[(study.fetchtype.str.upper() == 'PREMISE') & (study.channels.isna())].copy()

    premisestudy_channel.channels = np.where((premisestudy_channel.channels.isna() |
                                    (~premisestudy_channel.channels.astype(bool))), '12345', premisestudy_channel.channels.str[0])

    premisestudy_channel.channels = pd.to_numeric(premisestudy_channel.channels)
    # Merge df2 to premise studies where channel for a premise match those of the study

    df2_premisestudy_channel = df2_premisestudy.merge(
        premisestudy_channel[['studyid', 'channels']].rename(
            columns={'channels': 'channel'}),
        how='inner', on=['studyid','channel'])  # .sort_values('premiseid')

    df2_premisestudy = df2_premisestudy.merge(
        premisestudy[['studyid']],
        how='inner', on=['studyid'])  # .sort_values('premiseid')

    df2_premisestudy = df2_premisestudy.append(df2_premisestudy_channel)

    ## Define ratestudies
    ratestudy = study[study.fetchtype.str.upper() == 'RATESTUDY'].copy()

    # Impute 12345 for all ratecode studies that don't specify a channel
    # 12345 will be used to match to 'totalized' channels (9,109,119 for net meters, or just 1 for non-nm)
    # ratestudy.channels = np.where(ratestudy.channels.isna(), '12345', ratestudy.channels.str[0])
    ratestudy.channels = np.where((ratestudy.channels.isna() |
                                   (~ratestudy.channels.astype(bool))), '12345', ratestudy.channels.str[0])

    # Make a separate row for each ratecode
    # explode requires pandas 0.25.0 or newer
    ratestudy_explode = ratestudy.explode('ratecodes')

    #ratestudy_explode.ratecodes = pd.to_numeric(ratestudy_explode.ratecodes)
    ratestudy_explode.channels = pd.to_numeric(ratestudy_explode.channels)

    # Fill channel with channel 9 for DUPROWS meters (would be net meters)
    df2.loc[(~df2.meterid.isna()) & (df2.meterstop_dt.isna()), 'channel'] = 2

    # Make sure net meter channels make it to ALR even when intervals can't be fetched
    df2.loc[(df2.channel.isna()) & (df2.netmeter==1), 'channel'] = 9

    df2.ratecode = df2['ratecode'].astype(str).replace('\.0', '', regex=True)
    # Merge df2 to ratestudies where ratecode and channel for a premise match those of the study
    df2_ratestudy = df2[~(df2.channel == 2000)].merge(
        ratestudy_explode[['studyid', 'ratecodes', 'channels']].rename(
            columns={'ratecodes': 'ratecode', 'channels': 'channel'}),
        how='left', on=['ratecode', 'channel'])  # .sort_values('premiseid')

    # Count to see if premise is part of a ratestudy (so we know whether or not we need BILLONLY)
    df2_ratestudy = df2_ratestudy.merge(df2_ratestudy[~df2_ratestudy.studyid.isna()].groupby(
        ['premiseid', 'accountid']).count()['studyid'].reset_index().rename(columns={'studyid':'ratestudy_cnt'}),
                                        how ='left', on = ['premiseid', 'accountid'])

    # Account for "BILLONLY" channel 1 meters that are calculated as part of bill before change to net meter
    df2_ratestudy.loc[(df2_ratestudy.channel == 1) &
                      (df2_ratestudy.nm_cnt > 0) &
                      (df2_ratestudy.meterstop_dt <= df2_ratestudy.billstop) &
                      (df2_ratestudy.ratestudy_cnt > 0), 'studyid'] = "BILLONLY"

    # Remove studies that are only in a premise study
    df2_ratestudy = df2_ratestudy[~df2_ratestudy.studyid.isna()]



    # # Keep track of powerbilling premises
    # df2_pb = df2[df2.premiseid.isin(df2[(df2.metertype == 'MULTIPB') | (df2.metertype == 'SOLARN')].premiseid)]

    # Create binary column in df2 for totalized like logic above
    # Subset df2 for just the 'totalized' channels, and create a column filled with 12345 to match to 'totalized' channels in ratestudy
    # We'll also include all powerbilling premises to df2_totalized, since we need to match non-totalized channels to these studies also
    df2_totalized = df2[
        (  df2.premiseid.isin(df2_pb.premiseid)) |
          (df2.channel.isna()) |
        ((~df2.premiseid.isin(df2_pb.premiseid)) & (df2.channel == 9)) |
        ((~df2.premiseid.isin(df2_pb.premiseid)) & (~df2.premiseid.isin(df2_ratestudy[df2_ratestudy.studyid == 'BILLONLY'].premiseid)) & (df2.channel == 1))
        ].copy()
    df2_totalized['totalized'] = 12345

    # Merge df2 to ratestudy on totalized
    df2_totalized_merge = df2_totalized.merge(
        ratestudy_explode[['studyid', 'ratecodes', 'channels']].rename(
            columns={'ratecodes': 'ratecode', 'channels': 'totalized'}),
        how='left', on=['ratecode', 'totalized'])

    df2_totalized_merge = df2_totalized_merge[~df2_totalized_merge.studyid.isna()].drop(['totalized'], axis=1)

    # Add df2_totalized_merge back to df2_ratestudy
    df2_ratestudy = df2_ratestudy.append(df2_totalized_merge)

    # # Fixing problem where powerbilling channels were being added to net meter studies
    # df2_ratestudy = df2_ratestudy[~((df2_ratestudy.studyid.str.contains('NET')) & (df2_ratestudy.netmeter != 1))]
    df2_ratestudy = df2_ratestudy[~((df2_ratestudy.studyid.str.contains('NET')) &
                                    (df2_ratestudy.netmeter != 1) &
                                    (~df2_ratestudy.netmeter.isna()) &
                                    (df2_ratestudy.non_billed_nm != 1))]

    # Remove meters that have net meter channels but are not billed as net meters from net meter studies
    df2_ratestudy = df2_ratestudy[~((df2_ratestudy.studyid.str.contains('NET')) & (df2_ratestudy.non_billed_nm == 1))]

    # Get old studypoint names for rate studies, merge to df2_ratestudy
    df2_ratestudy = df2_ratestudy.merge(fetch_results_old[fetch_results_old.studyid.isin(ratestudy.studyid)][
                                            ['premiseid', 'company', 'studyid', 'studypoint']].drop_duplicates(), how='left',
                                        on=['premiseid', 'company', 'studyid']).drop_duplicates()

    # Each premise retains the same study point for a given study from before if the premise has previously been in ALR for that study.
    # Should be same studypoint across the 3 channels for net meter studies.
    # If a premise is not already in ALR for a given study, the premise is given a new studypoint that is greater than the current maximum studypoint for a study

    # Group fetch_results_old by study, find max
    max_studypoints = fetch_results_old.groupby('studyid').agg({'studypoint': 'max'}).reset_index()

    # For studies that weren't in ALR before, set the max to 0 by looping, appending to max_studypoints
    for s in ratestudy.studyid.unique():
        if (s not in (max_studypoints.studyid.unique())):
            max_studypoints = max_studypoints.append(pd.DataFrame({'studyid': [s], 'studypoint': [0]}))
    max_studypoints = max_studypoints.drop_duplicates()

    # Make sure net studies all have the same max starting point across the three channels
    for s in max_studypoints.studyid.unique():
        if s[-4:-1] == 'NET':
            max_studypoints.loc[max_studypoints.studyid == s, 'studypoint'] = max_studypoints.loc[
                max_studypoints.studyid.str.contains(s[0:-1]), 'studypoint'].max()

    max_studypoints_rate = max_studypoints[max_studypoints.studyid.isin(ratestudy.studyid)]

    new_studypoints_all = pd.DataFrame()

    if len(df2_ratestudy) > 0:
        if len(fetch_results_old) > 0:
            df2_ratestudy_new = df2_ratestudy[df2_ratestudy.studypoint.isna()]
            df2_ratestudy = df2_ratestudy[~df2_ratestudy.studypoint.isna()]

            if len(df2_ratestudy_new) > 0:
                for s in max_studypoints_rate.studyid:
                    if s[-4:-1] == 'NET':
                        new_studypoints = pd.DataFrame({'premiseid': df2_ratestudy_new[
                            df2_ratestudy_new.studyid.str.contains(s[0:-1])].premiseid.unique()})
                        new_studypoints['studyid'] = s
                        new_studypoints['studypoint'] = new_studypoints.index + 1 + max_studypoints_rate[
                            max_studypoints_rate.studyid == s].studypoint.values[0]
                        new_studypoints_all = new_studypoints_all.append(new_studypoints)
                    else:
                        new_studypoints = pd.DataFrame(
                            {'premiseid': df2_ratestudy_new[df2_ratestudy_new.studyid == s].premiseid.unique()})
                        new_studypoints['studyid'] = s
                        new_studypoints['studypoint'] = new_studypoints.index + 1 + max_studypoints_rate[
                            max_studypoints_rate.studyid == s].studypoint.values[0]
                        new_studypoints_all = new_studypoints_all.append(new_studypoints)

                df2_ratestudy_new = df2_ratestudy_new.drop(['studypoint'], axis=1).merge(new_studypoints_all, how='left',
                                                                                         on=['premiseid', 'studyid'])
                df2_ratestudy = df2_ratestudy.append(df2_ratestudy_new)
        else:
            for s in df2_ratestudy.studyid.unique():
                if s[-4:-1] == 'NET':
                    new_studypoints = pd.DataFrame(
                        {'premiseid': df2_ratestudy[df2_ratestudy.studyid.str.contains(s[0:-1])].premiseid.unique()})
                    new_studypoints['studyid'] = s
                    new_studypoints['studypoint'] = new_studypoints.index + 1
                    new_studypoints_all = new_studypoints_all.append(new_studypoints)
                else:
                    new_studypoints = pd.DataFrame(
                        {'premiseid': df2_ratestudy[df2_ratestudy.studyid == s].premiseid.unique()})
                    new_studypoints['studyid'] = s
                    new_studypoints['studypoint'] = new_studypoints.index + 1
                    new_studypoints_all = new_studypoints_all.append(new_studypoints)
            df2_ratestudy = df2_ratestudy.drop(['studypoint'], axis=1).merge(new_studypoints_all, how='left',
                                                                             on=['premiseid', 'studyid'])
    # BILLONLY won't have studypoints
    df2_ratestudy.loc[df2_ratestudy.studyid == "BILLONLY", 'studypoint'] = np.nan

    # Bring df2 for ratestudies back with df2 for premise studies
    df2 = df2_ratestudy.append(df2_premisestudy)

    # Now change the "fake 1's" back to channel 2, remove duplicates based on primary keys (keep last to keep fake_1_flg)
    df2.loc[df2.fake_1_flg == 1, 'channel'] = 2.0

    df2_pks = [
        'studyid',
        'premiseid',
        'accountid',
        'meterid',
        'channel',
        'rltv_mo',
        'bill_date',
        'meterstart_dt',
        'billstop'
    ]
    df2 = df2.drop_duplicates(subset=df2_pks, keep='last')

    '''Dataframe Definitions
    df2:           interval cuts at channel level = fetch_results
    df2_grouped:   interval cuts aggregated at premise, account level (needed for missing interval checks) = premise_usage
    df2_9:         interval cuts at channel level with only aggregated channels for net meters/power billing (9/109/119)
    df2_9_grouped: interval cuts aggregated at premise, account level, but with only aggregated channels for net
                   meters/power billing (9/109/119) (needed for bill comparison)
    '''


    df2_9 = df2[((df2.channel == 1) & (~df2.premiseid.isin(df2_pb.premiseid.unique())) & (df2.non_billed_nm == 0)) |
                #((df2.channel == 1000) & (~df2.premiseid.isin(df2_pb.premiseid.unique())) & (df2.non_billed_nm == 0) & (df2.meterid == 'evmeter')) |
                ((df2.channel == 1000) & (~df2.premiseid.isin(df2_pb.premiseid.unique())) & (df2.non_billed_nm == 0) & (df2.metertype == 'evmeter')) |
                ((df2.channel == 9) & (~df2.premiseid.isin(df2_pb.premiseid.unique())) & (df2.non_billed_nm == 0)) |
                ((df2.channel == 2) & (~df2.premiseid.isin(df2_pb.premiseid.unique())) & (df2.non_billed_nm == 1)) |
                ((df2.channel == 109) & (df2.premiseid.isin(df2_pb.premiseid.unique())) & (~df2.premiseid.isin(df2_sst.premiseid.unique())) & (df2.non_billed_nm == 0)) |
                ((df2.channel == 629) & (df2.premiseid.isin(df2_sst.premiseid.unique())) & (df2.non_billed_nm == 0)) |
                ((df2.channel == 119) & (df2.premiseid.isin(df2_pb.premiseid.unique())) & (~df2.premiseid.isin(df2_sst.premiseid.unique())) & (df2.non_billed_nm == 0))
                ]


    # Calculate bad/good interval % for interval counts
    df2['badintvper']  = df2['badintvcount']  / (df2['badintvcount'] + df2['goodintvcount'] + df2['interpolated'])
    df2['goodintvper'] = df2['goodintvcount'] / (df2['badintvcount'] + df2['goodintvcount'] + df2['interpolated'])
    df2['interpolper'] = df2['interpolated']  / (df2['badintvcount'] + df2['goodintvcount'] + df2['interpolated'])

    # Group df2 by premise/account and study. i.e. Aggregate meters if multiple meters
    df2_grouped = df2.groupby(['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop']).sum()[
        ['goodintvcount', 'badintvcount', 'interpolated']].reset_index()

    # Calculate bad/good interval % for aggregated interval counts
    df2_grouped['badintvper'] = df2_grouped['badintvcount'] / (
            df2_grouped['badintvcount'] + df2_grouped['goodintvcount'] + df2_grouped['interpolated'])
    df2_grouped['goodintvper'] = df2_grouped['goodintvcount'] / (
            df2_grouped['badintvcount'] + df2_grouped['goodintvcount'] + df2_grouped['interpolated'])
    df2_grouped['interpolper'] = df2_grouped['interpolated']  / (
            df2_grouped['badintvcount'] + df2_grouped['goodintvcount'] + df2_grouped['interpolated'])

    # Group df2_9 by premise/account and study. i.e. Aggregate only channel 9 for net meters (for bill comparison)
    df2_9_grouped = df2_9[df2_9.studyid != "BILLONLY"].groupby(['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop']).sum()[
        ['kwh']].reset_index()
    # Do this separately for "BILLONLY" studies (we can't group two studies together since non-nm premises might have >1
    # study, which would then double the aggregation)
    df2_9_grouped_billonly = df2_9[df2_9.studyid == "BILLONLY"].groupby(['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop']).sum()[
        ['kwh']].reset_index()

    # Add kwh for "BILLONLY" studies back to the respective premise/accountid for net studies
    # (non-net studies already aggregate all channels)
    df2_9_grouped = df2_9_grouped.merge(df2_9_grouped_billonly[['premiseid', 'accountid', 'bill_date', 'billstop','kwh']], how='left',
                                        on=['premiseid', 'accountid', 'bill_date', 'billstop'])
    df2_9_grouped.kwh_y = df2_9_grouped.kwh_y.fillna(0)
    df2_9_grouped['kwh'] = np.where(df2_9_grouped.studyid.str.contains("NET"),
                                    df2_9_grouped.kwh_x + df2_9_grouped.kwh_y, df2_9_grouped.kwh_x)

    # Join df2_9_grouped back to df2_grouped to get the total kwh for each premise
    df2_grouped = df2_grouped.merge(df2_9_grouped[['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop', 'kwh']], how='left',
                                    on=['premiseid', 'accountid', 'bill_date', 'billstop', 'studyid'])

    df2_grouped_notnull = df2_grouped[~df2_grouped.kwh.isna()]
    df2_grouped_null = df2_grouped[df2_grouped.kwh.isna()].drop(['kwh'], axis = 1)

    df2_grouped_null = df2_grouped_null.merge(df2[['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop', 'kwh']], how='left',
                                    on=['premiseid', 'accountid', 'bill_date', 'billstop', 'studyid'])

    df2_grouped_null = df2_grouped_null.drop_duplicates()
    df2_grouped_null = df2_grouped_null.groupby(['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop','goodintvcount', 'badintvcount', 'interpolated','badintvper','goodintvper','interpolper']).sum()[
        ['kwh']].reset_index()

    df2_grouped = df2_grouped_notnull.append(df2_grouped_null)

    # Get max meterstop for incomplete interval check
    df2_max_meter_stop = df2[~df2.meterstop_dt.isna()].groupby(['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop']).agg(
        {'meterstop_dt': 'max'}).reset_index()

    df2_grouped = df2_grouped.merge(df2_max_meter_stop,
                                    how='left', on=['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop'])

    # Left join df2_grouped to df2 so that we can keep all of the premise info needed
    df2_grouped = df2_grouped.merge(df2.drop(
        ['meterid', 'metertype', 'meterstart_dt', 'meterstop_dt', 'channel', 'kwh', 'goodintvcount', 'badintvcount',
         'interpolated', 'goodintvper', 'badintvper', 'interpolper'], axis=1),
        how='left', on=['premiseid', 'accountid', 'bill_date', 'studyid', 'billstop']).drop_duplicates()

    df2_grouped = df2_grouped.drop(['netmeter', 'channel_cnt', 'channel_cnt_meter', 'nm_cnt'], axis=1).drop_duplicates()

    # BILLONLY Shouldn't go through to premise_usage or error, so remove it from df2_grouped
    df2_grouped = df2_grouped[df2_grouped.studyid != 'BILLONLY']

    error_df = pd.DataFrame(
        columns=['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id'])

    '''
    SPI Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At channel level

    print("Performing SPI Check")

    # Create spi flag, 0 for good and 1 for bad
    df2['spi_flg'] = np.where(df2.spi_check > 1, 1, 0)

    # Write to error table where spi is flagged (i.e. if distinct spi values > 1)
    error_df_append = df2[df2.spi_flg == 1][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'meterid', 'channel']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "SPI")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    SPI Length Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At channel level

    print("Performing SPI Length Check")

    # Write to error table where spi is greater than 60 minutes (3600 seconds)
    error_df_append = df2[df2.spi > 60][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'meterid', 'channel']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "SPILENGTH")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    No Data Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At premise-aggregated channel level

    print("Performing No Data Check")

    # # Group by premiseid, studyid, channel and count number of kwh that are nan (to do this, make binary 'nodata' column)
    # # "                               "    and count number of meters per premise/channel
    # df2['nodata'] = np.where(df2.kwh.isna(), 1, 0)
    # nodata_cnt = df2.groupby(['premiseid', 'studyid', 'channel']).sum()['nodata'].reset_index()
    # meter_cnt = df2.groupby(['premiseid', 'studyid', 'channel']).count()['meterid'].reset_index()
    # nodata_cnt = nodata_cnt.merge(meter_cnt, how='left', on=['premiseid', 'studyid', 'channel'])
    # nodata_cnt = nodata_cnt.rename(columns={'nodata': 'nodata_cnt', 'meterid': 'meter_cnt'})
    #
    # # Then join back to df2, filter for where nodata_cnt == meter_cnt, and write to error_table
    # # (i.e. data is unavailable for all meters for the channel)
    # error_df_append = df2.merge(nodata_cnt[nodata_cnt.nodata_cnt == nodata_cnt.meter_cnt], how='right',
    #                             on=['premiseid', 'studyid', 'channel'])[
    #     ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'channel']].drop_duplicates()
    #df2['nodata'] = np.where(df2.kwh.isna(), 1, 0)
    error_df_append = df2[df2.kwh.isna()][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "NODATA")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    Missing Interval % Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At premise/account level

    print("Performing Missing Interval Check")

    # Write to error table if point's % of intervals missing >= x% after interpolation is attempted
    error_df_append = df2_grouped[df2_grouped.badintvper > missing_perc_thresh][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'badintvper']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "BADINTV")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    Bill Comparison Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At premise/account level

    print("Performing Bill Comparison Check")

    # Calculate difference between billkwh and kwh
    df2_grouped['diffbillcompper'] = np.where(df2_grouped['billkwh'] > 0,
                                        (df2_grouped['kwh'] - df2_grouped['billkwh']) / df2_grouped['billkwh'],
                                     np.where((df2_grouped['billkwh'] == 0) & (df2_grouped['kwh'] == 0),
                                        0,
                                     np.nan))

    # Write to error table if difference between billed_kwh and cut kwh > 10%
    error_df_append = df2_grouped[abs(df2_grouped.diffbillcompper) > bill_diff_thresh][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'kwh', 'billkwh']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "DIFFBILLCOMP")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]


    # Log null bill errors also (if billkwh is null or 0, and cut kwh not 0)
    error_df_append = df2_grouped[(df2_grouped.billkwh == 0 | df2_grouped.billkwh.isna()) & (df2_grouped.kwh != 0)][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "NULLBILL")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    Incomplete Intervals Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At premise/bill level

    print("Performing Incomplete Intervals Check")

    # Write to error table where the max meterstop_dt is less than the billstop
    df2_grouped1 = df2_grouped[~df2_grouped.meterstop_dt.isna()].copy()
    error_df_append = df2_grouped1[df2_grouped1.meterstop_dt < df2_grouped1.billstop][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'meterstop_dt', 'billstop']]

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "INCOMPINTVS")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    Duplicate Rows Error Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At meter level

    print("Performing Duplicate Rows Error Check")

    # Write to error table where meterid is not null but meterstop is null
    error_df_append = df2[(~df2.meterid.isna()) & (df2.meterstop_dt.isna())][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "DUPROWS")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    Average Usage Months Used Check
    --------------------------------------------------------------------------------------------------------------------
    '''
    # At premise/account level

    print("Performing Average Usage Months Used Check")

    # Write to error table if num_months_monthlyavg < aumonth
    error_df_append = df2_grouped[df2_grouped.num_months_monthlyavg < aumonth][
        ['studyid', 'premiseid', 'rltv_mo', 'studypoint', 'num_months_monthlyavg']].drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "AUMONTH")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    '''
    Meter Change Check
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Performing Meter Change Check")

    # Group df2 by premise/channel and study, count the number of meters per channel per premise
    df2_premchan = df2.groupby(['premiseid', 'studyid', 'channel']).count()[['meterid']].rename(
        columns={'meterid': 'metercnt'})
    df2_premchan = df2_premchan.merge(df2[['premiseid', 'studyid', 'channel', 'meterid', 'metertype', 'meterstart_dt',
                                           'meterstop_dt', 'billstart', 'billstop']], how='left',
                                      on=['premiseid', 'studyid', 'channel'])

    # For issues with reading in meter dates:
    df2_premchan['meterstart_dt2'] = pd.to_datetime(df2_premchan.meterstart_dt, utc=True, errors='coerce').fillna(
        pd.Timestamp.max.date())
    df2_premchan['meterstop_dt2'] = pd.to_datetime(df2_premchan.meterstop_dt, utc=True, errors='coerce', ).fillna(
        pd.Timestamp.max.date())

    df2_premchan['billstart2'] = pd.to_datetime(df2_premchan.billstart, utc=True, errors='coerce').fillna(pd.Timestamp.max.date())
    df2_premchan['billstop2'] = pd.to_datetime(df2_premchan.billstop, utc=True, errors='coerce').fillna(pd.Timestamp.max.date())

    # Create a column startstop for whether or not there was a meter stop or a meter start (started, stopped, or nan)
        # If meter stop date on or before bill stop date
            # Log meter stop
        # If meter start date on or after bill start date
            # Log meter start

    df2_premchan['startstop'] = np.where(df2_premchan.meterstop_dt2 <= df2_premchan.billstop2, "stopped",
                                np.where(df2_premchan.meterstart_dt2 >= df2_premchan.billstart2, "started",
                                         np.nan))

    # Then choose the corresponding startstopdate based on above
    df2_premchan['startstopdate'] = np.where(df2_premchan.startstop == "started", df2_premchan.meterstart_dt,
                                    np.where(df2_premchan.startstop == "stopped", df2_premchan.meterstop_dt,
                                             np.nan))

    # Merge back to df2_grouped to get studypoint and rltv_mo
    # Write to error table if a meter stopped or started
    error_df_append = df2_premchan[(df2_premchan.startstop == "stopped") |
                                   (df2_premchan.startstop == "started")].merge(
        df2[['premiseid', 'studyid', 'rltv_mo', 'studypoint']],
        how='left', on=['premiseid', 'studyid']).drop_duplicates()

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "METERCHANGE")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    study2 = study.copy()
    study2.channels = study2.channels.str[0]

    # Use np.where logic (i.e. if else) to determine which channels are True for study_channel_flg
    # (i.e. which channels are actually written to files)
    df2 = df2.merge(study2[['studyid', 'channels']].drop_duplicates(), how='left', on='studyid')
    df2['study_channel_flg'] = np.where((df2.channels.isna()) &
                                        ((df2.channel.isin([1,9]) & ~df2.premiseid.isin(df2_pb.premiseid.unique())) |
                                         (df2.channel.isin([109,119]) & df2.premiseid.isin(df2_pb.premiseid.unique()) & ~df2.premiseid.isin(df2_sst.premiseid.unique())) |
                                         (df2.channel.isin([629]) & df2.premiseid.isin(df2_sst.premiseid.unique()))),
                                            1,
                               np.where(((df2.channel == 2) & (df2.channels == 2)) |
                                        ((df2.channel == 4) & (df2.channels == 4)) |
                                        ((df2.channel == 1000) & (df2.channels == 1000)) |
                                        ((df2.channel == 2000) & (df2.channels == 2000)) |
                                        ((df2.channel == 9) & (df2.channels == 9)),
                                            1,
                               np.where((df2.channels == 1) &
                                        (((df2.channel == 1) & ~df2.premiseid.isin(df2_pb.premiseid.unique())) |
                                        ((df2.channel == 109) & df2.premiseid.isin(df2_pb.premiseid.unique()))),
                                            1,
                               # Else
                                            0)))
    df2.study_channel_flg = np.where(df2.studyid == 'BILLONLY', 0, df2.study_channel_flg)
    df2.study_channel_flg = np.where((df2.netmeter == 0) &
                                     (~df2.premiseid.isin(df2_pb.premiseid)) &
                                     (df2.channel.isin([4, 9])), 0, df2.study_channel_flg)
    df2.study_channel_flg = np.where((df2.netmeter == 0) &
                                     (~df2.premiseid.isin(df2_pb.premiseid)) &
                                     (df2.channel == 2), 1, df2.study_channel_flg)

    # Create fetch_results_new from df2
    fetch_results_new = df2[[
        'bill_date',
        'studyid',
        'company',
        'premiseid',
        'rltv_mo',
        'meterid',
        'channel',
        'studypoint',
        'customer',
        'accountid',
        'metertype',
        'metermtpl',
        'meterstart_dt',
        'meterstop_dt',
        'netmeter',
        'spi_flg',
        'kwh',
        'study_channel_flg',
        'goodintvper',
        'badintvper',
        'interpolper',
        'billstop'
    ]].copy()

    fetch_results_new['updated_dt'] = np.nan
    fetch_results_new['process_run_date'] = np.nan
    fetch_results_new['job_run_id'] = np.nan

    # Create premise_usage from df2_grouped
    premise_usage_new = df2_grouped[[
        'studyid',
        'company',
        'rltv_mo',
        'premiseid',
        'customer',
        'accountid',
        'account_status',
        'ratecode',
        'zipcode',
        'streetaddress',
        'wc_dist',
        'kwh',
        'diffbillcompper',
        'billstart',
        'billstop',
        'billkwh',
        'avgmonthlykwh',
        'studypoint',
        'goodintvper',
        'badintvper',
        'interpolper',
        'bill_date'
    ]].copy()

    premise_usage_new['updated_dt'] = np.nan
    premise_usage_new['process_run_date'] = np.nan
    premise_usage_new['job_run_id'] = np.nan

    # Keep track of which premises have a net meter (or did at some point throughout month)
    nm_premises = df2[df2.netmeter == 1].premiseid

    # Log error for the rows  that need to be filtered
    error_df_append = fetch_results_new[
        (fetch_results_new.studyid.str.upper().str.contains("PURE") & fetch_results_new.premiseid.isin(nm_premises))][
        ['premiseid', 'studyid', 'rltv_mo', 'studypoint']]

    # Send rows to append to function, if any available
    if len(error_df_append) > 0:
        error_df = append_error_df(error_df, error_df_append, "PURESTUDY")[
            ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
             'process_run_date', 'job_run_id']]

    prem_err_cols = [
        'ratecode',       # premise_usage
        'zipcode',        # premise_usage
        'streetaddress',  # premise_usage
        'wc_dist',        # premise_usage
        'metermtpl',      # fetch_results     # if no meter change
        'netmeter',       # fetch_results    ## as well as meter change
        'channels'        # fetch_results     # if no meter change
    ]

    info_err_cols = [
        'customer',  # premise_usage / multiple accounts
        'accountid',  # premise_usage / multiple accounts
        'account_status'  # premise_usage / multiple accounts
        # multiple accounts = Check for two accounts in same rltv_mo
        # premise_usage = Check premise_usage for non-accountid change and/or change occuring exactly inline with cycle
            # When we do premise_usage comparison, filter out  for changes we already captured
    ]

    # multiple account comparisons

    # Group premise_usage_new at premise level, count the number of accounts. Merge back to premise_usage_new to keep info
    premise_usage_accts = premise_usage_new.groupby(['premiseid', 'rltv_mo']).agg('nunique')[['accountid']].rename(
        columns={'accountid': 'accountcnt'})
    premise_usage_accts = premise_usage_accts.merge(premise_usage_new, how='left', on=['premiseid', 'rltv_mo'])

    # Filter for only multi-account premises, then separate into new and old
    premise_usage_accts = premise_usage_accts[premise_usage_accts.accountcnt > 1]
    premise_usage_accts_new = premise_usage_accts.groupby('premiseid').agg({'bill_date': 'max'}).reset_index().merge(
        premise_usage_new[['premiseid', 'bill_date'] + info_err_cols], how='left',
        on=['premiseid', 'bill_date']).drop_duplicates()
    premise_usage_accts_old = premise_usage_accts.groupby('premiseid').agg({'bill_date': 'min'}).reset_index().merge(
        premise_usage_new[['premiseid', 'bill_date'] + info_err_cols], how='left',
        on=['premiseid', 'bill_date']).drop_duplicates()

    # Join new and old together to compare info_err_cols
    premise_usage_accts = premise_usage_accts_new.merge(premise_usage_accts_old, how='left', on=['premiseid'],
                                                        suffixes=('_new', '_old'))
    premise_usage_accts_compare = premise_usage_accts[
        premise_usage_accts.accountid_new != premise_usage_accts.accountid_old].merge(
        premise_usage_new[['studyid', 'rltv_mo', 'premiseid', 'studypoint', 'bill_date']].rename(
            columns={'bill_date': 'bill_date_new'}), how='left', on=['premiseid', 'bill_date_new'])

    if len(premise_usage_accts_compare) > 0:
        # Create 'change' column and fill it with the names of the columns that changed
        premise_usage_accts_compare['change'] = premise_usage_accts_compare.apply(
            lambda x: compare_err_cols(x, info_err_cols[0:3]), axis=1)

        # Write to error table if 'change' is not empty
        error_df_append_info = premise_usage_accts_compare[premise_usage_accts_compare.change.str.len() > 0][
            ['studyid', 'rltv_mo', 'premiseid', 'studypoint', 'change'] + [col + "_new" for col in info_err_cols] + [
                col + "_old" for col in info_err_cols]]

        # Explode change array so that there is a new row for each change (i.e. a different error for each change)
        error_df_append_info = error_df_append_info.explode('change')

        # Set change_new and change_old columns equal to whichever columns changed
        error_df_append_info['change_new'] = np.where(error_df_append_info['change'] == info_err_cols[0],
                                                      error_df_append_info[info_err_cols[0] + '_new'],
                                             np.where(error_df_append_info['change'] == info_err_cols[1],
                                                      error_df_append_info[info_err_cols[1] + '_new'],
                                             np.where(error_df_append_info['change'] == info_err_cols[2],
                                                      error_df_append_info[info_err_cols[2] + '_new'],
                                                      np.nan)))
        error_df_append_info['change_old'] = np.where(error_df_append_info['change'] == info_err_cols[0],
                                                      error_df_append_info[info_err_cols[0] + '_old'],
                                             np.where(error_df_append_info['change'] == info_err_cols[1],
                                                      error_df_append_info[info_err_cols[1] + '_old'],
                                             np.where(error_df_append_info['change'] == info_err_cols[2],
                                                      error_df_append_info[info_err_cols[2] + '_old'],
                                                      np.nan)))

        error_df_append_info.drop_duplicates()

        # Send rows to append to function, if any available
        if len(error_df_append_info) > 0:
            error_df = append_error_df(error_df, error_df_append_info, "INFORMATIONAL")[
                ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id']]

    # Filter premise_usage_old and fetch_results_old (what was in ALR) for only the most recent rltv_mo
    # probably just last month for most, but might be older if a premise wasn't pulled last month for some reason
    # so that we can do comparisons to see what's changed
    if rltv_mo > 0:
        premise_usage_old = premise_usage_old[premise_usage_old.rltv_mo <= rltv_mo]
        fetch_results_old = fetch_results_old[fetch_results_old.rltv_mo <= rltv_mo]

    if len(premise_usage_old) > 0:
        # Group by premiseid, get maximum rltv_mo
        premise_ALR_max = premise_usage_old.groupby(['premiseid']).agg({'rltv_mo': 'max'}).reset_index()

        # Filter premise_usage_old for only most recent rltv_mo
        i1 = premise_usage_old.set_index(['premiseid', 'rltv_mo']).index
        i2 = premise_ALR_max.set_index(['premiseid', 'rltv_mo']).index
        premise_usage_old = premise_usage_old[i1.isin(i2)]

    if len(fetch_results_old) > 0:
        # Group by premiseid, get maximum rltv_mo
        fetch_ALR_max = fetch_results_old.groupby(['premiseid']).agg(
            {'rltv_mo': 'max'}).reset_index()

        # Filter fetch_results_old for only most recent rltv_mo
        i1 = fetch_results_old.set_index(['premiseid', 'rltv_mo']).index
        i2 = fetch_ALR_max.set_index(['premiseid', 'rltv_mo']).index
        fetch_results_old = fetch_results_old[i1.isin(i2)]


    '''
    Premise Usage Comparisons
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Performing Premise Usage Comparisons")

    # Group premise_usage_old at premise level, count the number of accounts, filter for only single-account premises
    # Since we already took wrote errors for premises that changed accounts last month
    premise_usage_old2 = premise_usage_old.groupby(['premiseid', 'rltv_mo']).agg('nunique')[['accountid']].rename(
        columns={'accountid': 'accountcnt'})
    premise_usage_old2 = premise_usage_old2.merge(premise_usage_old, how='left', on=['premiseid', 'rltv_mo'])
    premise_usage_old2 = premise_usage_old2[premise_usage_old2.accountcnt == 1]

    # Join premise_usage_new to premise_usage_old by premiseid
        # Have to do everything twice to separate premise errors from info errors
    premise_usage_compare_prem = premise_usage_new.merge(
        premise_usage_old2[prem_err_cols[0:4] + ['premiseid']], how='left',
        on=['premiseid'], suffixes=('_new', '_old'))
    premise_usage_compare_info = premise_usage_new.merge(
        premise_usage_old2[info_err_cols + ['premiseid']], how='left',
        on=['premiseid'], suffixes=('_new', '_old'))
    premise_usage_compare_prem = premise_usage_compare_prem.drop_duplicates()
    premise_usage_compare_info = premise_usage_compare_info.drop_duplicates()

    # Filter out premises with no streetaddress_old/accountid_old
        # (need some sort of proxy to find premises that haven't ever been in premise_usage)
    premise_usage_compare_prem = premise_usage_compare_prem[~premise_usage_compare_prem.streetaddress_old.isna()]
    premise_usage_compare_info = premise_usage_compare_info[~premise_usage_compare_info.accountid_old.isna()]

    if len(premise_usage_compare_prem) > 0:
        # Create 'change' column and fill it with the names of the columns that changed
        premise_usage_compare_prem['change'] = premise_usage_compare_prem.apply(
            lambda x: compare_err_cols(x, prem_err_cols[0:4]), axis=1)

        # Write to error table if 'change' is not empty
        error_df_append_prem = premise_usage_compare_prem[premise_usage_compare_prem.change.str.len() > 0][
            ['studyid', 'rltv_mo', 'premiseid', 'studypoint', 'change'] +
            [col + "_new" for col in prem_err_cols[0:4]] + [col + "_old" for col in prem_err_cols[0:4]]]

        # Explode change array so that there is a new row for each change (i.e. a different error for each change)
        error_df_append_prem = error_df_append_prem.explode('change')

        # Set change_new and change_old columns equal to whichever columns changed
        error_df_append_prem['change_new'] = np.where(error_df_append_prem['change'] == prem_err_cols[0],
                                                      error_df_append_prem[prem_err_cols[0] + '_new'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[1],
                                                      error_df_append_prem[prem_err_cols[1] + '_new'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[2],
                                                      error_df_append_prem[prem_err_cols[2] + '_new'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[3],
                                                      error_df_append_prem[prem_err_cols[3] + '_new'],
                                                      np.nan))))
        error_df_append_prem['change_old'] = np.where(error_df_append_prem['change'] == prem_err_cols[0],
                                                      error_df_append_prem[prem_err_cols[0] + '_old'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[1],
                                                      error_df_append_prem[prem_err_cols[1] + '_old'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[2],
                                                      error_df_append_prem[prem_err_cols[2] + '_old'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[3],
                                                      error_df_append_prem[prem_err_cols[3] + '_old'],
                                                      np.nan))))

        # Send rows to append to function, if any available
        if len(error_df_append_prem) > 0:
            error_df = append_error_df(error_df, error_df_append_prem, "PREMISE")[
                ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id']]

    if len(premise_usage_compare_info) > 0:
        # Create 'change' column and fill it with the names of the columns that changed
        premise_usage_compare_info['change'] = premise_usage_compare_info.apply(
            lambda x: compare_err_cols(x, info_err_cols), axis=1)

        # Write to error table if 'change' is not empty
        error_df_append_info = premise_usage_compare_info[premise_usage_compare_info.change.str.len() > 0][
            ['studyid', 'rltv_mo', 'premiseid', 'studypoint', 'change'] + [col + "_new" for col in info_err_cols] + [
                col + "_old" for col in info_err_cols]]

        # Explode change array so that there is a new row for each change (i.e. a different error for each change)
        error_df_append_info = error_df_append_info.explode('change')

        # Set change_new and change_old columns equal to whichever columns changed
        error_df_append_info['change_new'] = np.where(error_df_append_info['change'] == info_err_cols[0],
                                                      error_df_append_info[info_err_cols[0] + '_new'],
                                             np.where(error_df_append_info['change'] == info_err_cols[1],
                                                      error_df_append_info[info_err_cols[1] + '_new'],
                                             np.where(error_df_append_info['change'] == info_err_cols[2],
                                                      error_df_append_info[info_err_cols[2] + '_new'],
                                                      np.nan)))
        error_df_append_info['change_old'] = np.where(error_df_append_info['change'] == info_err_cols[0],
                                                      error_df_append_info[info_err_cols[0] + '_old'],
                                             np.where(error_df_append_info['change'] == info_err_cols[1],
                                                      error_df_append_info[info_err_cols[1] + '_old'],
                                             np.where(error_df_append_info['change'] == info_err_cols[2],
                                                      error_df_append_info[info_err_cols[2] + '_old'],
                                                      np.nan)))

        # Send rows to append to function, if any available
        if len(error_df_append_info) > 0:
            error_df = append_error_df(error_df, error_df_append_info, "INFORMATIONAL")[
                ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id']]

    '''
    Fetch Results Comparisons
    --------------------------------------------------------------------------------------------------------------------
    '''

    print("Performing Fetch Results Comparisons")

    # Make sure channels for a meter haven't changed.
    # Group old and new fetch_results by meter to see which channels each meter has
    meter_channel_new = fetch_results_new.groupby(['meterid']).agg({'channel': 'unique'}).reset_index().rename(
        columns={'channel': 'channels'})
    meter_channel_new.channels = meter_channel_new.channels.apply(lambda x: sorted(x))

    meter_channel_old = fetch_results_old.groupby(['meterid']).agg({'channel': 'unique'}).reset_index().rename(
        columns={'channel': 'channels'})
    meter_channel_old.channels = meter_channel_old.channels.apply(lambda x: sorted(x))

    # Join each back to fetch_results so that channels can be included in comparisons below
    fetch_results_new = fetch_results_new.merge(meter_channel_new, how='left', on='meterid')
    fetch_results_old = fetch_results_old.merge(meter_channel_old, how='left', on='meterid')

    # fetch_results_old.channel = fetch_results_old.meterid.astype(pd.Int32Dtype())
    # fetch_results_new.channel = fetch_results_new.meterid.astype(pd.Int32Dtype())
    # fetch_results_old.channel = fetch_results_old.channel.astype(pd.Int32Dtype())
    # fetch_results_new.channel = fetch_results_new.channel.astype(pd.Int32Dtype())
    # fetch_results_new.meterid = fetch_results_new.meterid.astype(str)
    # fetch_results_old.meterid = fetch_results_old.meterid.astype(str)
    # fetch_results_new.channel = np.floor(pd.to_numeric(fetch_results_new.channel, errors='coerce')).astype('Int64')
    # fetch_results_old.channel = np.floor(pd.to_numeric(fetch_results_old.channel, errors='coerce')).astype('Int64')

    # Join fetch_results_new to old fetch_results_old by premiseid, meterid, and channelid
        # Can join by meter since we're tracking meter changes separately
    fetch_results_compare_prem = fetch_results_new.merge(
        fetch_results_old[prem_err_cols[4:] + ['premiseid', 'meterid', 'channel']], how='left',
        on=['premiseid', 'meterid', 'channel'], suffixes=('_new', '_old'))

    # Filter out premises with no netmeter_old
        # (need some sort of proxy to find premises that haven't ever been in premise_usage)
    fetch_results_compare_prem = fetch_results_compare_prem[~fetch_results_compare_prem.netmeter_old.isna()]

    if len(fetch_results_compare_prem) > 0:
        # Create 'change' column and fill it with the names of the columns that changed
        fetch_results_compare_prem['change'] = fetch_results_compare_prem.apply(
            lambda x: compare_err_cols(x, prem_err_cols[4:]), axis=1)

        # Write to error table if 'change' is not empty
        error_df_append_prem = fetch_results_compare_prem[fetch_results_compare_prem.change.str.len() > 0][
            ['studyid', 'rltv_mo', 'premiseid', 'studypoint', 'change'] +
            [col + "_new" for col in prem_err_cols[4:]] + [col + "_old" for col in prem_err_cols[4:]]]

        # Explode change array so that there is a new row for each change (i.e. a different error for each change)
        error_df_append_prem = error_df_append_prem.explode('change')

        # Set change_new and change_old columns equal to whichever columns changed
        error_df_append_prem['change_new'] = np.where(error_df_append_prem['change'] == prem_err_cols[4],
                                                      error_df_append_prem[prem_err_cols[4] + '_new'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[5],
                                                      error_df_append_prem[prem_err_cols[5] + '_new'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[6],
                                                      error_df_append_prem[prem_err_cols[6] + '_new'],
                                                      np.nan)))
        error_df_append_prem['change_old'] = np.where(error_df_append_prem['change'] == prem_err_cols[4],
                                                      error_df_append_prem[prem_err_cols[4] + '_old'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[5],
                                                      error_df_append_prem[prem_err_cols[5] + '_old'],
                                             np.where(error_df_append_prem['change'] == prem_err_cols[6],
                                                      error_df_append_prem[prem_err_cols[6] + '_old'],
                                                      np.nan)))

        # Send rows to append to function, if any available
        if len(error_df_append_prem) > 0:
            error_df = append_error_df(error_df, error_df_append_prem, "PREMISE")[
                ['studyid', 'rltv_mo', 'errorcode', 'errormessage', 'process', 'premiseid', 'studypoint', 'updated_dt',
                 'process_run_date', 'job_run_id']]

    fetch_results_new = fetch_results_new.drop('channels', axis=1)

    '''
    Output
    --------------------------------------------------------------------------------------------------------------------
    '''
    # Make sure all have same updated_dt and drop duplicates
    updated_date = pd.to_datetime(datetime.now(pytz.timezone("US/Eastern")))

    premise_usage_new = premise_usage_new.drop_duplicates()
    premise_usage_new['updated_dt'] = updated_date
    fetch_results_new = fetch_results_new.drop_duplicates()
    fetch_results_new['updated_dt'] = updated_date
    error_df = error_df.drop_duplicates()
    error_df['updated_dt'] = updated_date

    fetch_results_new['process_run_date'] = process_run_date
    fetch_results_new['job_run_id'] = job_run_id
    premise_usage_new['process_run_date'] = process_run_date
    premise_usage_new['job_run_id'] = job_run_id
    error_df['process_run_date'] = process_run_date
    error_df['job_run_id'] = job_run_id

    print("Writing Tables to ALR")
    fetch_results_new.channel = fetch_results_new.channel.astype(pd.Int32Dtype())
    fetch_results_new.netmeter = fetch_results_new.netmeter.astype(pd.Int32Dtype())

    # Impute something instead of nulls for missing meters, since meterid is part of primary keys
    fetch_results_new.meterid = np.where(fetch_results_new.meterid.isna(), ' ', fetch_results_new.meterid)
    fetch_results_new.meterstart_dt = np.where(fetch_results_new.meterstart_dt.isna(), pd.Timestamp.min.date(), fetch_results_new.meterstart_dt)
    fetch_results_new.channel = np.where(fetch_results_new.channel.isna(), -1, fetch_results_new.channel)
    #Upsert BILLONLY separately
    fetch_results_BILLONLY = fetch_results_new[fetch_results_new.studyid == 'BILLONLY']
    fetch_results_new = fetch_results_new[fetch_results_new.studyid != 'BILLONLY']
    write_df_to_postgres(fetch_results_new, table_name=f'{schema}.fetch_results')
    upsert_to_postgres(fetch_results_BILLONLY, table_name='fetch_results')

    premise_usage_new.account_status = premise_usage_new.account_status.astype(pd.Int32Dtype())
    premise_usage_new.wc_dist = premise_usage_new.wc_dist.astype(pd.Int32Dtype())
#    premise_usage_new.ratecode = premise_usage_new.ratecode.astype(pd.Int32Dtype())
    premise_usage_new.zipcode = pd.to_numeric(premise_usage_new.zipcode, errors='coerce').astype(pd.Int32Dtype())
    # premise_usage_new.zipcode = premise_usage_new.zipcode.astype(pd.Int32Dtype())
    # premise_usage_new.billkwh = premise_usage_new.billkwh.astype(pd.Int32Dtype(), errors='ignore')
    premise_usage_new.billkwh = np.floor(pd.to_numeric(premise_usage_new.billkwh, errors='coerce')).astype('Int64')
    # write to S3 if you need to review a dataframe
    # csv_buffer = StringIO()
    # premise_usage_new.to_csv(csv_buffer, index=False, header=False, sep="|")
    # s3_resource = boto3.resource('s3')
    # s3_resource.Object('2fnv-lo174-alr-data-output-s3', 'premise_usage_new.csv').put(Body=csv_buffer.getvalue())
    write_df_to_postgres(premise_usage_new, table_name=f'{schema}.premise_usage')

    error_df.rltv_mo = error_df.rltv_mo.astype(pd.Int32Dtype())
    error_df.premiseid = error_df.premiseid.astype(pd.Int32Dtype())
    #Upsert BILLONLY separately
    error_BILLONLY = error_df[error_df.studyid == 'BILLONLY']
    error_df = error_df[error_df.studyid != 'BILLONLY']
    write_df_to_postgres(error_df, table_name=f'{schema}.error')
    upsert_to_postgres(error_BILLONLY, table_name='error')


def process_fetch(df2, backdated, audit_id, reprocessed = False):

    df2 = df2.drop_duplicates()

    # Clean customer name
    #df2.customer = np.where(df2.customer.str[-1] == '\\', df2.customer.str[0:-1], df2.customer)
    df2.customer = df2.customer.astype(str)
    df2.customer = np.where(df2.customer == 'nan', '', df2.customer)
    df2.customer = df2.customer.str.replace('\\', '')
    df2.customer = df2.customer.apply(lambda x: ' '.join(x.split()))
    df2.customer = df2.customer.str.strip()

    df2.streetaddress = df2.streetaddress.astype(str)
    df2.streetaddress = np.where(df2.streetaddress == 'nan', '', df2.streetaddress)
    df2.streetaddress = df2.streetaddress.str.replace('\\', '')
    df2.streetaddress = df2.streetaddress.apply(lambda x: ' '.join(x.split()))
    df2.streetaddress = df2.streetaddress.str.strip()

    df2.loc[~df2.meterid.isna(), 'meterid'] = df2[~df2.meterid.isna()].meterid.astype(str)
    df2.meterid = df2.meterid.str.replace('\.0', '')

    df2.ratecode = df2.ratecode.astype(str)

    process_run_date = df2.process_run_date.unique()[0]
    job_run_id = df2.job_run_id.unique()[0]

    study = read_ALR(['study'])[1]

    current_mo = datetime.now(pytz.timezone("US/Eastern")).date().year * 100 + \
                 datetime.now(pytz.timezone("US/Eastern")).date().month


    if not backdated:
        studies = study[(study.enddate   >= datetime.now(pytz.timezone("US/Eastern")).date() - timedelta(8)) &
                        (study.startdate <= datetime.now(pytz.timezone("US/Eastern")).date())].studyid
        print(studies)

        # Perform validations
        validations(df2, process_run_date=process_run_date, job_run_id=job_run_id, studyids=studies)

        # For daily processes, call automatic switching function on or after the 21st day of month following the rltv_mo
            # Will call only when the rltv_mo is not yet in active_premise for the active studies
        if (datetime.now(pytz.timezone("US/Eastern")).date().day >= switch_trig_day):
            print(f"Checking if switching has occurred yet for {get_previous_mo(current_mo)}")
            # Get list of studies that are active (end date greater than current date -31)
                # -31 cuz even after study ends, might still switch up to a month later
            #studies = study[study.enddate > datetime.now(pytz.timezone("US/Eastern")).date()].studyid
            studies_switch = study[study.enddate > datetime.now(pytz.timezone("US/Eastern")).date()- timedelta(31)].studyid.unique()


            # Check if last rltv_mo is in active_premise. Will return empty data frame if not
            active_premise = read_ALR(['active_premises'],
                                      rltv_mo=get_previous_mo(current_mo))[5]

            # If not, switch
            if len(active_premise) == 0:
                automatic_switching(rltv_mo = get_previous_mo(current_mo), studyids = studies_switch,
                                    process_run_date = process_run_date, job_run_id = job_run_id)
            else:
                print("Switching already done")

    elif backdated:
        # Get list of studies that have been fetched to S3, but have not been validated
        if not reprocessed:
            etl_backdated = read_ALR(['etl_backdated'])[6]
            rltv_mo = df2.rltv_mo.unique()[0]
            studies = etl_backdated[(etl_backdated.rltv_mo == rltv_mo) &
                                    (etl_backdated.validation_run_date.isna())].studyid.unique()

            print(studies)

        else:
            reprocessed_studies = read_ALR('study_to_reprocess')[8]
            rltv_mo = df2.rltv_mo.unique()[0]
            studies = reprocessed_studies[(reprocessed_studies.rltv_mo == rltv_mo) &
                                          (reprocessed_studies.validation_run_date.isna())].studyid.unique()
            print(studies)

            # Delete old data from database so we can reprocess
            print("Deleting old records before reprocessing")
            delete_old_records("fetch_results", studies, rltv_mo)
            delete_old_records("premise_usage", studies, rltv_mo)
            delete_old_records("error", studies, rltv_mo)
            delete_old_records("active_premise", studies, rltv_mo)

        # Perform validations
        validations(df2, process_run_date=process_run_date, job_run_id=job_run_id, rltv_mo=df2.rltv_mo.unique()[0],
                    studyids=studies)

        # For backdated processes, call automatic switching function for rltv_mo of df2
        now = datetime.now(pytz.timezone("US/Eastern")).date()
        then = now + relativedelta.relativedelta(months=-1)
        # If today on or after 21st (switching day), switch if rltv_mo before current month
        # If today before 21st (switching day), switch if rltv_mo before prior month
        if (now.day >= switch_trig_day):
            if now.year * 100 + now.month > rltv_mo:
                automatic_switching(rltv_mo=rltv_mo, studyids=studies, process_run_date=process_run_date,
                                    job_run_id=job_run_id)
        else:
            if then.year * 100 + then.month > rltv_mo:
                automatic_switching(rltv_mo=rltv_mo, studyids=studies, process_run_date=process_run_date,
                                    job_run_id=job_run_id)

        # Write to etl_backdated if backdated, or study_to_reprocess if reprocess
        if audit_id != '':
            validation_run_day = str(datetime.now(pytz.timezone("US/Eastern")).date().year) + \
                                 str(datetime.now(pytz.timezone("US/Eastern")).date().month).zfill(2) + \
                                 str(datetime.now(pytz.timezone("US/Eastern")).date().day).zfill(2)

            premise_usage = read_ALR(['premise_usage'], rltv_mo)[3]
            premise_usage = premise_usage[premise_usage.studyid.isin(studies)]
            if not reprocessed:
                print("Recording in etl_backdated")
                last_process_days = premise_usage.groupby('studyid').agg({'billstop': 'max'}).reset_index()
                last_process_days.apply(lambda x: update_etl_backdated(study=x['studyid'], day=x['billstop'],
                                                                       val_dt=validation_run_day, val_id=rltv_mo, # Issues with audit_id, changing to rltv_mo
                                                                       rltv_mo=rltv_mo), axis=1)
            else:
                print("Recording in study_to_reprocess")
                [update_study_to_reprocess(s, validation_run_day, rltv_mo) for s in premise_usage.studyid.unique()]

    print("Finished")



def get_spark_env():
    conf = SparkConf().set("spark.jars", "/home/hadoop/jars/postgresql-42.2.12.jar,/home/hadoop/jars/mssql-jdbc-8.2.2.jre8.jar,/home/hadoop/jars/cobol-parser-0.2.5.jar,/home/hadoop/jars/spark-cobol-0.2.5.jar,/home/hadoop/jars/scodec-core_2.11-1.10.3.jar,/home/hadoop/jars/scodec-bits_2.11-1.1.4.jar")\
        .set('spark.executor.memory', '37G')\
        .set('spark.driver.memory', '37G') \
        .set("spark.executor.memoryOverhead", "5g") \
        .set('spark.kryoserializer.buffer.max', '128m')

    spark = SparkSession.builder. \
        appName("loadresearch"). \
        config(conf=conf). \
        getOrCreate()
    return spark

def main():
    '''
    :argument greg_date: string, like "202108" for backdated or "2021-08-26" for daily
    :argument audit_id: string
    '''

    options = parse_arguments(sys.argv)
    greg_date = options.get('greg_date').strip()
    audit_id = options.get('audit_id').strip()
    process = options.get('process').strip().lower()

    # Spark environment
    spark = get_spark_env()

    starttime = datetime.now()


    # If only writing to csv's, need to remove existing csv files so we don't append to them
    # if os.path.isfile('active_premise.csv'):
    #     os.remove('active_premise.csv')
    # if os.path.isfile('fetch_results.csv'):
    #     os.remove('fetch_results.csv')
    # if os.path.isfile('premise_usage.csv'):
    #     os.remove('premise_usage.csv')
    # if os.path.isfile('error.csv'):
    #     os.remove('error.csv')


    s3 = boto3.resource('s3')

    bucket = get_connection_jdbc(sm_client, connection_key, 'alr_s3')['data_bucket_name']

    # # Based on format of greg_date argument, determine whether or not process backdated
    # if len(greg_date) == 6:
    #     backdated = True
    # elif len(greg_date) > 6:
    #     backdated = False
    #
    # reprocessed = False
    #
    # if company == 'FPL':
    #     folder = ["fpl_alr_backdate/" if backdated==True else "fpl_alr/"][0]
    #     prefix = ["fpl_alr_backdate_" if backdated==True else "fpl_alr_"][0]
    # elif company == 'GE':
    #     folder = ["gulf_alr_backdate/" if backdated==True else "gulf_alr/"][0]
    #     prefix = ["gulf_alr_backdate_" if backdated==True else "gulf_alr_"][0]
    # else:
    #     print("No folder for specified company")

    backdated = reprocessed = False
    if (process == 'backdate') | (process == 'reprocess'):
        backdated = True
    if process == 'reprocess':
        reprocessed = True

    folder = f"alr_{process}/"

    '''
    ex.: s3://2fnv-lo174-cs-data-input/alr_backdate/GE_202107/part-00000-d34a3069-30b5-413a-a605-d97a11996bae-c000.csv
    '''

    df2 = pd.DataFrame()
    for obj in s3.Bucket(bucket).objects.filter(Prefix=folder):
    # for obj in s3.Bucket(bucket).objects.filter(Prefix=folder + prefix + str(greg_date)):
        if str(greg_date) in obj.key and obj.size > 0:
            file = "s3://" + bucket + "/" + obj.key
            print("File found: " + file)

            print("Reading in file from S3")
            # Read files from S3 to pandas (requires s3fs package)
            df2 = df2.append(pd.read_csv(file))

    try:
        if len(df2.index) != 0:
            process_fetch(df2, backdated, audit_id, reprocessed)
        else:
            eSubjectName = 'Validation Process: No Data'
            eerror = f"The Validation process failed today due to no data. Please check fetch process logs and ALR for valid studies."
            if Topic != None:
                send_sns(region_name, Topic.strip(), eerror, eSubjectName[:100])

            if cw_log_group != None:
                put_error_cloudwatch(region_name, cw_log_group.strip(), eerror)
    except Exception as e:
        print(e)
        eSubjectName = 'Validation Process Failed'
        eerror = f"Below is the failure details :\n\n{e}"

        if Topic != None:
            send_sns(region_name, Topic.strip(), eerror, eSubjectName[:100])

        if cw_log_group != None:
            put_error_cloudwatch(region_name, cw_log_group.strip(), eerror)

    print("Time elapsed:")
    print(datetime.now() - starttime)


if __name__=="__main__":
    main()