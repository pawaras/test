import sys
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql import *
from functions import *


def interpolation_fill(df, partition, read_time, read_value, intdatafirst, intdatasecond , nivel = 'DATE'):



    partition_1 = partition.copy()
    partition_2 = partition.copy()
    partition_3 = partition.copy()
    partition_4 = partition.copy()

    partition_2.append('day_of_week')
    partition_3.extend(['day_of_week', 'hour_to_agg', 'minute_to_agg'])
    partition_4.extend(['status', 'n_row'])

    window_1 = Window.partitionBy(partition_2).orderBy('hour_to_agg','minute_to_agg')
    window_2 = Window.partitionBy(partition_1).orderBy('day_of_week', 'hour_to_agg', 'minute_to_agg')
    window_3 = Window.partitionBy(partition_1).orderBy('day_of_week', 'hour_to_agg','minute_to_agg').rowsBetween(0, sys.maxsize)



    df = df.withColumn('day_of_week', dayofweek(F.col(read_time))).withColumn("hour_to_agg", hour(col(read_time))).withColumn("minute_to_agg", minute(col(read_time)))

    interpolation_agg = df.groupBy(partition_3).agg(F.avg(F.col('kwh')).alias('avg_kw'))



    interpolation_agg = interpolation_agg.withColumn('lag_1',  F.lag(F.col('avg_kw')).over(window_1))\
        .withColumn('lag_3', F.last(F.col('avg_kw')).over(window_3))\
        .withColumn('lag_2', F.lag(F.col('avg_kw')).over(window_2))

    interpolation_agg = interpolation_agg.withColumn('value_change', F.col('avg_kw') - (F.coalesce(F.col('lag_1'),F.col('lag_2'),F.col('lag_3'))) )


    _interval = df.groupBy (partition) \
        .agg(F.min("interval_from_date").cast('timestamp').alias('interval_from_date'),
             F.max("interval_to_date").cast('timestamp').alias('interval_to_date'),\
             (F.max("spi")*60).alias('interval_spi'), \
            F.max("spi").alias('spi_agg'))

    _interval = _interval.withColumn("readtime_min", F.col('interval_from_date').cast('integer')) \
        .withColumn("readtime_max", F.col('interval_to_date').cast('integer'))

    df = df.withColumn("readtime", F.col(read_time).cast('integer'))
    drop_columns = ['interval_from_date',  'interval_to_date']
    df= df.drop(*drop_columns)

    # generate timegrid and explode
    _interval = _interval.withColumn("readtime", F.explode(date_range("readtime_min", "readtime_max", "interval_spi")))
    _interval = _interval.withColumn('date_read', to_date(F.from_unixtime(F.col('readtime'))))

    partition.append('readtime')
    df_all_dates = _interval.join(df, partition, "left")
    df_all_dates = df_all_dates.withColumn('read_time', F.col('readtime').cast('timestamp'))

    if nivel == 'DATE':
        df_all_dates = df_all_dates.withColumn('status', F.expr("CASE WHEN read_strt_time is null and channel not in (1000,2000) and date_read >= meterstart and date_read <= date_add(meterstop, -1)  then 9 WHEN  (date_read < meterstart or date_read >= meterstop) then -1 else null end"))
    elif nivel== 'GULF':
        df_all_dates = df_all_dates.withColumn('status', F.expr(
            "CASE WHEN read_strt_time is null and channel != 1000 and  (date_read >= meterstart and date_read <= meterstop)   then 9 WHEN  (date_read < meterstart or date_read > meterstop)  then -1 else null end"))
    else:
        df_all_dates = df_all_dates.withColumn('status', F.expr("CASE WHEN read_strt_time is null and read_time >= meterstart and read_time <= meterstop  then 9 WHEN  (read_time < meterstart or read_time > meterstop) then -1 else null end"))

    df_all_dates = df_all_dates.filter(((F.col('status').isNull()) | (F.col('status') == 9)))



    df_all_dates = df_all_dates.withColumn('intdatafirst', F.lit(intdatafirst))
    df_all_dates = df_all_dates.withColumn('intdatasecond', F.lit(intdatasecond))

    df_all_dates = df_all_dates.withColumn('total_row', F.count(F.col('premiseid')).over(Window.partitionBy(partition_1)))

    df_all_dates = df_all_dates.withColumn('total_null', F.count(F.col('read_strt_time')).over(Window.partitionBy(partition_1)))


    df_all_dates = df_all_dates.withColumn('missing_p', ((F.col('total_row')-F.col('total_null'))/F.col('total_row')))
    # interpolation


    df_all_dates = df_all_dates.withColumn('day_of_week', dayofweek(F.col('read_time'))).withColumn("hour_to_agg", hour(col('read_time'))).withColumn("minute_to_agg", minute(col('read_time')))

    if nivel == 'DATE':
        df_all_dates =df_all_dates.join(interpolation_agg.select('premiseid', 'uev_site', 'accountid', 'meterid', 'channel','spi', 'metertype', 'metermtpl', 'meterstart', 'meterstop', 'netmeter',
                                                                 'billstart', 'billstop', 'day_of_week', 'hour_to_agg', 'minute_to_agg','value_change' ), partition_3, 'left')
    else:
        df_all_dates =df_all_dates.join(interpolation_agg.select('premiseid', 'accountid', 'meterid', 'channel','spi', 'metertype', 'metermtpl', 'meterstart', 'meterstop', 'netmeter',
                                                                 'billstart', 'billstop', 'day_of_week', 'hour_to_agg', 'minute_to_agg','value_change' ), partition_3, 'left')

    df_all_dates = df_all_dates.withColumn('n_row', F.count(F.col('read_strt_time')).over(Window.partitionBy(partition_1).orderBy(F.col('readtime'))))

    df_all_dates = df_all_dates.withColumn('n_null', F.when(F.col('read_strt_time').isNull(), F.row_number().over(
        Window.partitionBy(partition_4).orderBy('readtime'))).otherwise(F.lit(0)))

    df_all_dates = df_all_dates.withColumn('max_missing', F.when(F.col('read_strt_time').isNull(), F.max(F.col('n_null')).over(
        Window.partitionBy(partition_4))).otherwise(F.lit(0)))





    window_ff = Window.partitionBy(partition_1) \
        .orderBy('readtime') \
        .rowsBetween(-sys.maxsize, 0)

    window_bf = Window.partitionBy(partition_1) \
        .orderBy('readtime') \
        .rowsBetween(0, sys.maxsize)


    read_last = F.last(df_all_dates['kwh'],ignorenulls=True).over(window_ff)
    read_next = F.first(df_all_dates['kwh'],ignorenulls=True).over(window_bf)


    df_all_dates = df_all_dates.withColumn('readvalue_ff', read_last).withColumn('readvalue_bf', read_next)
    #df_all_dates = df_all_dates.withColumn('readvalue_ff', F.coalesce(F.col('readvalue_ff'),F.lit(0))).withColumn('readvalue_bf', F.coalesce(F.col('readvalue_bf'),F.lit(0)))

    df_all_dates = df_all_dates.withColumn('sum_change',F.when(F.col('status') == 9, F.sum('value_change').over(
                                               Window.partitionBy(partition_4).orderBy('readtime'))).otherwise(F.lit(None)))



    df_all_dates = df_all_dates.withColumn('StraightLineFactor',F.when((F.col('status')==9) , ((F.col('readvalue_bf')-F.col('readvalue_ff'))/(F.col('max_missing')+1) )).otherwise(F.lit(0)))

    df_all_dates = df_all_dates.withColumn('interpolate_1',F.when(((F.col('status') == 9) & (( F.col('spi_agg') == 15) & ( F.col('max_missing') <= 4))),
                                                  (F.col('readvalue_ff') + F.col('StraightLineFactor')) +(F.col('StraightLineFactor')*(F.col('n_null')-1)))\
                                           .otherwise(F.lit(None)))

    df_all_dates = df_all_dates.withColumn('interpolate_2',F.when(((F.col('status') == 9) & ((( F.col('spi_agg') == 15) & (F.col('max_missing') < 96) ) | (( F.col('spi_agg') == 60) & (F.col('max_missing') < 24) )) ) ,(F.col('readvalue_ff') + F.col('sum_change')))\
                                           .otherwise(F.lit(None)))

    df_all_dates = df_all_dates.withColumn('interpolate',F.when((((F.col('intdatafirst') < F.col('missing_p')) & (F.col('missing_p') <= F.col('intdatasecond'))) & (F.col('status') == 9)), F.coalesce(F.col('interpolate_1'), F.col('interpolate_2')))
                                           .otherwise(F.lit(None)))

    if nivel != 'TIMESTAMP':
        df_all_dates = df_all_dates.withColumn('status', F.when(((F.col('intdatafirst') < F.col('missing_p')) & (F.col('missing_p') <= F.col('intdatasecond'))) & (F.col('status') == 9) & (F.col('interpolate').isNotNull()), F.lit('I')).otherwise(F.col('status')))
        df_all_dates = df_all_dates.withColumn('kwh', F.when(F.col('status') == 'I',F.greatest(F.col('interpolate'), F.lit(0))).otherwise(F.col('kwh')))

    drop_columns = ['total_row', 'total_null','value_change', 'n_row', 'n_null', 'max_missing', 'readvalue_ff', 'readvalue_bf', 'sum_change', 'StraightLineFactor', 'interpolate_1', 'interpolate_2', 'interpolate']
    df_all_dates = df_all_dates.drop(*drop_columns)
    return  df_all_dates
